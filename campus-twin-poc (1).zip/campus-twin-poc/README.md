# Campus Digital Twin — POC

## Fastest path: the live demo build (frontend only)

The `frontend/` app runs **fully self-contained** in demo mode — no Firebase
network call, no backend, no internet needed. Six rooms, live-looking
occupancy/CO2/temperature/energy/Wi-Fi data, five prediction types
(overcrowding, energy anomaly, utilization, next-hour energy forecast, peak
ranking), an AI copilot (chat + next-step planner), and a manual "add reading" lever per
room to prove it live on stage.

```
cd frontend
npm install
npm run dev
```

Open the printed URL, sign in with **any email/password** (demo mode accepts
anything, no account is actually created), and you're on the building
overview. Two rooms are pre-staged so you don't have to touch anything to
show the interesting cases: **Electronics Lab is overcrowded**, **Seminar
Hall has an energy anomaly**. Click into any room for its detail view,
charts, and the "add a reading" form; use the copilot's suggestion chips
or type your own question.

Do a full run-through tonight, not just tomorrow morning — see "What to
verify before you present" below.

### Twin Copilot: Claude AI (optional) and the offline brain

The overview has two AI surfaces, both fed the same live twin snapshot
(`frontend/src/lib/snapshot.js`): per-room readings, model outputs, 1-hour
trends, and current/next timetable slot.

- **Twin Copilot** (chat): answers questions and lights up the rooms it's
  talking about on the floor plan.
- **Next best actions**: decides what the facilities team should do now
  (ventilate, relocate a class, cut idle load, inspect equipment...). Each
  action has an **Apply to twin** button that changes the twin's state, so
  you can show the effect live, then **Re-plan**.

To use Claude, put a key in `frontend/.env` and restart `npm run dev`:

```
ANTHROPIC_API_KEY=sk-ant-...
TWIN_AI_MODEL=claude-opus-5
```

The key is read by the Vite server (`frontend/server/twinAi.js`, mounted in
`vite.config.js` at `/api/twin/*`), so it never reaches the browser and
there is no CORS problem. The top bar shows "Claude · model" when it's on.

With no key, no internet, or any API error, both surfaces fall back
automatically to the offline brain (`frontend/src/lib/brain.js`) and the
rule-based planner (`frontend/src/lib/advisor.js`). These understand room
names ("LH2", "electronics"), metrics, rankings, "find a room for 40", "why
is X flagged", schedules, and "what should we do next". Each answer is
labelled with its source (Claude or Offline brain).

Note: `/api/twin/*` exists in `npm run dev`, `npm run preview`, and on
Vercel (below). Other static hosts would need the same handler as a function.

### Deploying to Vercel

`frontend/` is a ready-to-deploy Vercel project: the Vite build is served
as a static SPA (`frontend/vercel.json`) and `frontend/api/twin/[action].js`
runs the Claude copilot as a serverless function.

Option A, from the CLI:

```
cd frontend
npx vercel            # first run links/creates the project; accept the defaults
npx vercel env add ANTHROPIC_API_KEY   # optional, enables Claude
npx vercel --prod
```

Option B, from GitHub: push the repo, import it at vercel.com/new, and set
**Root Directory** to `frontend`. Framework, build command and output
directory are picked up from `vercel.json`.

Environment variables (Project → Settings → Environment Variables):

| Variable | Needed? | Notes |
|---|---|---|
| `ANTHROPIC_API_KEY` | Optional | Without it the copilot runs on the offline brain. |
| `TWIN_AI_MODEL` | Optional | Defaults to `claude-opus-5`. |
| `VITE_DEMO_MODE` | Optional | Unset = demo mode (mock login and data). |
| `VITE_FIREBASE_*` | Only if `VITE_DEMO_MODE=false` | Copy from `frontend/.env`. |

`.env` is gitignored and is not uploaded, so set these in Vercel. Redeploy
after changing a `VITE_` variable, because those are baked in at build time.

### What to run before presenting

1. `cd frontend && npm install && npm run dev`, open it, sign in, click
   through all 6 rooms once.
2. Try 2-3 copilot questions, then "Apply to twin" on one recommended action.
3. Try "Add a reading" on one room with CO2 above 1000 and occupied
   checked — confirm the overcrowding alert appears live.
4. If anything looks off, tell me and I'll fix it before you present.

## What's real vs. simulated (say this upfront to faculty)

- **CS Lab 1**: occupancy, temperature, and CO2 come from a real public
  sensor dataset (UCI Occupancy Detection). Energy is synthetic but
  calibrated (baseline + occupancy load + HVAC term + noise).
- **The other 5 rooms**: fully synthetic, generated to look like a real
  campus day, so the demo can show the multi-room, building-wide version of
  the idea without needing five rooms of real sensors right now.
- This mirrors exactly what the proposal document argues: prove the
  pipeline on one real room, simulate the rest to show how it scales.

## Everything else in this folder

- `data/` — the real+synthetic seed dataset prep for the single-room
  backend path (`scripts/prepare_data.py`, `data/README.md` for the schema).
- `backend/` — Node/Express API for the single-room path, backed by a local
  SQLite file (or real Firestore — `backend/src/store/FirestoreStore.js`).
  Not needed for tomorrow's demo; this is where the real trained prediction
  models and a real backend-mediated LLM call will live next.
- `frontend/src/firebase.js`, `AuthContext.jsx`, `hooks/useFirestoreRoom.js`
  — the real Firebase Auth + Firestore path for the single room, still
  there, just switched off by `VITE_DEMO_MODE=true` in `frontend/.env`. Flip
  it to `false` once you've verified Email/Password + Firestore rules are
  live on `ib-review` (steps I gave you earlier), on a machine with normal
  internet — I can't verify that connection from this sandbox.
