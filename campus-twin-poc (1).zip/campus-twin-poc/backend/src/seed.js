import fs from "node:fs";
import path from "node:path";
import { createStore } from "./store/index.js";

const ROOM_ID = "room-a";
const DATA_DIR = path.resolve("../data/processed");

async function main() {
  const store = await createStore();

  const readings = JSON.parse(fs.readFileSync(path.join(DATA_DIR, "seed_readings.json"), "utf-8"));
  const timetable = JSON.parse(fs.readFileSync(path.join(DATA_DIR, "timetable.json"), "utf-8"));

  const rCount = await store.seedReadings(ROOM_ID, readings);
  const tCount = await store.seedTimetable(ROOM_ID, timetable);

  console.log(`Seeded ${rCount} readings and ${tCount} timetable entries for ${ROOM_ID}.`);

  const latest = await store.latestReading(ROOM_ID);
  console.log("Latest reading:", latest);
}

main().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
