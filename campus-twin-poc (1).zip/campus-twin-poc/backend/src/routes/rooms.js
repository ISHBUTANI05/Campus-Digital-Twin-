import { Router } from "express";

export function roomsRouter(store) {
  const router = Router();

  // Current state: latest reading + timetable, so the dashboard has
  // everything it needs for the "live" view in one call.
  router.get("/:roomId/state", async (req, res) => {
    const { roomId } = req.params;
    const [latest, timetable] = await Promise.all([
      store.latestReading(roomId),
      store.listTimetable(roomId),
    ]);
    if (!latest) return res.status(404).json({ error: "no readings for this room yet" });
    res.json({ room_id: roomId, latest, timetable });
  });

  // History for the chart. ?since=ISO_TIMESTAMP&limit=N
  router.get("/:roomId/readings", async (req, res) => {
    const { roomId } = req.params;
    const { since, limit } = req.query;
    const readings = await store.listReadings(roomId, {
      since,
      limit: limit ? Number(limit) : undefined,
    });
    res.json({ room_id: roomId, count: readings.length, readings });
  });

  // The manual "proof lever": add a reading and watch state/prediction move.
  router.post("/:roomId/readings", async (req, res) => {
    const { roomId } = req.params;
    const body = req.body || {};

    if (body.co2_ppm == null && body.temperature_c == null && body.energy_kwh == null) {
      return res.status(400).json({
        error: "provide at least one of co2_ppm, temperature_c, energy_kwh (plus occupied)",
      });
    }

    // Derive the same proxies the seed data uses, so a manual entry behaves
    // identically to a real one for prediction/anomaly purposes.
    const occupied = !!body.occupied;
    const co2 = body.co2_ppm ?? null;
    const overcrowded = occupied && co2 != null && co2 > 1000;

    const reading = {
      timestamp: body.timestamp ?? new Date().toISOString(),
      temperature_c: body.temperature_c ?? null,
      humidity_pct: body.humidity_pct ?? null,
      co2_ppm: co2,
      occupied,
      crowding_index: co2 != null ? Math.min(1, Math.max(0, (co2 - 400) / (2000 - 400))) : null,
      overcrowded,
      energy_kwh: body.energy_kwh ?? null,
      energy_anomaly: false, // ground truth unknown for a manual entry; the model decides
    };

    const saved = await store.addManualReading(roomId, reading);
    res.status(201).json({ room_id: roomId, reading: saved });
  });

  router.get("/:roomId/timetable", async (req, res) => {
    const { roomId } = req.params;
    const timetable = await store.listTimetable(roomId);
    res.json({ room_id: roomId, timetable });
  });

  return router;
}
