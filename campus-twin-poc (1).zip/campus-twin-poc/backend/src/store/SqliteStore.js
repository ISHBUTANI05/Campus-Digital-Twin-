import Database from "better-sqlite3";
import { Store } from "./Store.js";

export class SqliteStore extends Store {
  constructor(dbPath = "data/campus_twin.db") {
    super();
    this.db = new Database(dbPath);
    this.db.pragma("journal_mode = WAL");
  }

  async init() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS readings (
        room_id TEXT NOT NULL,
        timestamp TEXT NOT NULL,
        temperature_c REAL,
        humidity_pct REAL,
        co2_ppm REAL,
        occupied INTEGER,
        crowding_index REAL,
        overcrowded INTEGER,
        energy_kwh REAL,
        energy_anomaly INTEGER,
        source TEXT,
        PRIMARY KEY (room_id, timestamp)
      );
      CREATE TABLE IF NOT EXISTS timetable (
        room_id TEXT NOT NULL,
        entry_id TEXT NOT NULL,
        day_of_week TEXT,
        start_time TEXT,
        end_time TEXT,
        subject TEXT,
        capacity INTEGER,
        expected_headcount INTEGER,
        PRIMARY KEY (room_id, entry_id)
      );
      CREATE INDEX IF NOT EXISTS idx_readings_room_ts ON readings(room_id, timestamp);
    `);
  }

  async seedReadings(roomId, readings) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO readings
      (room_id, timestamp, temperature_c, humidity_pct, co2_ppm, occupied,
       crowding_index, overcrowded, energy_kwh, energy_anomaly, source)
      VALUES (@room_id, @timestamp, @temperature_c, @humidity_pct, @co2_ppm, @occupied,
              @crowding_index, @overcrowded, @energy_kwh, @energy_anomaly, @source)
    `);
    const insertMany = this.db.transaction((rows) => {
      for (const r of rows) {
        stmt.run({
          room_id: roomId,
          timestamp: r.timestamp,
          temperature_c: r.temperature_c,
          humidity_pct: r.humidity_pct,
          co2_ppm: r.co2_ppm,
          occupied: r.occupied ? 1 : 0,
          crowding_index: r.crowding_index,
          overcrowded: r.overcrowded ? 1 : 0,
          energy_kwh: r.energy_kwh,
          energy_anomaly: r.energy_anomaly ? 1 : 0,
          source: r.source ?? "seed",
        });
      }
    });
    insertMany(readings);
    return readings.length;
  }

  async seedTimetable(roomId, entries) {
    const stmt = this.db.prepare(`
      INSERT OR REPLACE INTO timetable
      (room_id, entry_id, day_of_week, start_time, end_time, subject, capacity, expected_headcount)
      VALUES (@room_id, @entry_id, @day_of_week, @start_time, @end_time, @subject, @capacity, @expected_headcount)
    `);
    const insertMany = this.db.transaction((rows) => {
      rows.forEach((r, i) => {
        stmt.run({
          room_id: roomId,
          entry_id: `${r.day_of_week}-${i}`,
          day_of_week: r.day_of_week,
          start_time: r.start_time,
          end_time: r.end_time,
          subject: r.subject,
          capacity: r.capacity,
          expected_headcount: r.expected_headcount,
        });
      });
    });
    insertMany(entries);
    return entries.length;
  }

  _row(r) {
    if (!r) return null;
    return {
      ...r,
      occupied: !!r.occupied,
      overcrowded: !!r.overcrowded,
      energy_anomaly: !!r.energy_anomaly,
    };
  }

  async latestReading(roomId) {
    const row = this.db
      .prepare(`SELECT * FROM readings WHERE room_id = ? ORDER BY timestamp DESC LIMIT 1`)
      .get(roomId);
    return this._row(row);
  }

  async listReadings(roomId, { since, limit = 500 } = {}) {
    let query = `SELECT * FROM readings WHERE room_id = ?`;
    const params = [roomId];
    if (since) {
      query += ` AND timestamp >= ?`;
      params.push(since);
    }
    query += ` ORDER BY timestamp ASC LIMIT ?`;
    params.push(limit);
    const rows = this.db.prepare(query).all(...params);
    return rows.map((r) => this._row(r));
  }

  async addManualReading(roomId, reading) {
    const doc = {
      room_id: roomId,
      timestamp: reading.timestamp ?? new Date().toISOString(),
      temperature_c: reading.temperature_c ?? null,
      humidity_pct: reading.humidity_pct ?? null,
      co2_ppm: reading.co2_ppm ?? null,
      occupied: reading.occupied ? 1 : 0,
      crowding_index: reading.crowding_index ?? null,
      overcrowded: reading.overcrowded ? 1 : 0,
      energy_kwh: reading.energy_kwh ?? null,
      energy_anomaly: reading.energy_anomaly ? 1 : 0,
      source: "manual",
    };
    this.db
      .prepare(
        `INSERT OR REPLACE INTO readings
         (room_id, timestamp, temperature_c, humidity_pct, co2_ppm, occupied,
          crowding_index, overcrowded, energy_kwh, energy_anomaly, source)
         VALUES (@room_id, @timestamp, @temperature_c, @humidity_pct, @co2_ppm, @occupied,
                 @crowding_index, @overcrowded, @energy_kwh, @energy_anomaly, @source)`
      )
      .run(doc);
    return this._row(doc);
  }

  async listTimetable(roomId) {
    const rows = this.db
      .prepare(`SELECT * FROM timetable WHERE room_id = ? ORDER BY day_of_week, start_time`)
      .all(roomId);
    return rows;
  }
}
