import { getApps, initializeApp, applicationDefault, cert } from "firebase-admin/app";
import { getFirestore } from "firebase-admin/firestore";
import { Store } from "./Store.js";

/**
 * Real Firestore-backed store. Used when STORE_BACKEND=firestore.
 *
 * Points at the emulator automatically if FIRESTORE_EMULATOR_HOST is set
 * (e.g. "localhost:8080" — set this when you run `firebase emulators:start`
 * on your own machine). Otherwise uses real credentials:
 *   - GOOGLE_APPLICATION_CREDENTIALS pointing at a service-account JSON, or
 *   - FIREBASE_SERVICE_ACCOUNT_JSON containing the JSON inline (e.g. in a
 *     deployment secret).
 *
 * Collection layout matches SqliteStore's tables exactly:
 *   rooms/{roomId}/readings/{timestamp}
 *   rooms/{roomId}/timetable/{entryId}
 */
export class FirestoreStore extends Store {
  constructor() {
    super();
    if (!getApps().length) {
      const projectId = process.env.FIREBASE_PROJECT_ID || "demo-campus-twin";
      if (process.env.FIRESTORE_EMULATOR_HOST) {
        initializeApp({ projectId });
      } else if (process.env.FIREBASE_SERVICE_ACCOUNT_JSON) {
        initializeApp({ credential: cert(JSON.parse(process.env.FIREBASE_SERVICE_ACCOUNT_JSON)) });
      } else {
        initializeApp({ credential: applicationDefault(), projectId });
      }
    }
    this.db = getFirestore();
  }

  async init() {
    // Firestore is schemaless — nothing to create up front.
  }

  _readingsCol(roomId) {
    return this.db.collection("rooms").doc(roomId).collection("readings");
  }

  _timetableCol(roomId) {
    return this.db.collection("rooms").doc(roomId).collection("timetable");
  }

  async seedReadings(roomId, readings) {
    const col = this._readingsCol(roomId);
    const chunks = [];
    for (let i = 0; i < readings.length; i += 400) chunks.push(readings.slice(i, i + 400));
    for (const chunk of chunks) {
      const batch = this.db.batch();
      for (const r of chunk) batch.set(col.doc(r.timestamp), r);
      await batch.commit();
    }
    return readings.length;
  }

  async seedTimetable(roomId, entries) {
    const col = this._timetableCol(roomId);
    const batch = this.db.batch();
    entries.forEach((r, i) => batch.set(col.doc(`${r.day_of_week}-${i}`), r));
    await batch.commit();
    return entries.length;
  }

  async latestReading(roomId) {
    const snap = await this._readingsCol(roomId).orderBy("timestamp", "desc").limit(1).get();
    return snap.empty ? null : snap.docs[0].data();
  }

  async listReadings(roomId, { since, limit = 500 } = {}) {
    let q = this._readingsCol(roomId).orderBy("timestamp", "asc");
    if (since) q = q.where("timestamp", ">=", since);
    q = q.limit(limit);
    const snap = await q.get();
    return snap.docs.map((d) => d.data());
  }

  async addManualReading(roomId, reading) {
    const doc = { ...reading, room_id: roomId, source: "manual", timestamp: reading.timestamp ?? new Date().toISOString() };
    await this._readingsCol(roomId).doc(doc.timestamp).set(doc);
    return doc;
  }

  async listTimetable(roomId) {
    const snap = await this._timetableCol(roomId).get();
    return snap.docs.map((d) => d.data());
  }
}
