/**
 * Store interface every backing implementation must satisfy, mirroring the
 * Firestore document model described in data/README.md:
 *   rooms/{roomId}/readings/{timestamp}
 *   rooms/{roomId}/timetable/{entryId}
 *
 * Two implementations:
 *  - SqliteStore    — local dev/test backend used inside this sandbox, since
 *                      the Firestore emulator binary can't be downloaded here.
 *  - FirestoreStore — the real backend, used when FIRESTORE_EMULATOR_HOST is
 *                      set (emulator on your machine) or real credentials are
 *                      supplied (live deployment). Same method signatures.
 *
 * Swap via the STORE_BACKEND env var — nothing above this layer changes.
 */
export class Store {
  /** @returns {Promise<void>} */
  async init() { throw new Error("not implemented"); }

  /** Bulk-load seed readings/timetable (used once, at setup time). */
  async seedReadings(_roomId, _readings) { throw new Error("not implemented"); }
  async seedTimetable(_roomId, _entries) { throw new Error("not implemented"); }

  /** @returns {Promise<object|null>} the most recent reading for a room */
  async latestReading(_roomId) { throw new Error("not implemented"); }

  /**
   * @returns {Promise<object[]>} readings for a room, ordered by timestamp asc,
   * optionally filtered to timestamp >= since (ISO string) and limited.
   */
  async listReadings(_roomId, { since, limit } = {}) { throw new Error("not implemented"); }

  /** Add one manually-entered reading; returns the stored document. */
  async addManualReading(_roomId, _reading) { throw new Error("not implemented"); }

  /** @returns {Promise<object[]>} the room's weekly timetable entries */
  async listTimetable(_roomId) { throw new Error("not implemented"); }
}
