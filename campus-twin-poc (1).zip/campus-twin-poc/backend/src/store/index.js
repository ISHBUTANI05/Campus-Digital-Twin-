import { SqliteStore } from "./SqliteStore.js";

/**
 * STORE_BACKEND=sqlite   (default here) — local dev/test inside this sandbox.
 * STORE_BACKEND=firestore — real backend; requires either FIRESTORE_EMULATOR_HOST
 *   (run `firebase emulators:start` on your own machine) or real credentials.
 * Firestore is imported lazily so firebase-admin never has to initialize
 * (and try to reach the network) when running on sqlite.
 */
export async function createStore() {
  const backend = process.env.STORE_BACKEND || "sqlite";
  if (backend === "firestore") {
    const { FirestoreStore } = await import("./FirestoreStore.js");
    const store = new FirestoreStore();
    await store.init();
    return store;
  }
  const store = new SqliteStore(process.env.SQLITE_PATH || "data/campus_twin.db");
  await store.init();
  return store;
}
