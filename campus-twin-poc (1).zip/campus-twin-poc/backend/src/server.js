import express from "express";
import cors from "cors";
import { createStore } from "./store/index.js";
import { roomsRouter } from "./routes/rooms.js";

const PORT = process.env.PORT || 4001;

async function main() {
  const store = await createStore();

  const app = express();
  app.use(cors());
  app.use(express.json());

  app.get("/api/health", (req, res) => res.json({ ok: true, backend: process.env.STORE_BACKEND || "sqlite" }));
  app.use("/api/rooms", roomsRouter(store));

  app.listen(PORT, () => {
    console.log(`campus-twin backend listening on :${PORT} (store=${process.env.STORE_BACKEND || "sqlite"})`);
  });
}

main().catch((err) => {
  console.error("Server failed to start:", err);
  process.exit(1);
});
