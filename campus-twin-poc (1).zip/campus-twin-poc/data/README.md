# Seed Data — Schema & Provenance

Scope: one room ("room-a") for the POC.

## Sources

- **Occupancy, temperature, humidity, CO2** — real sensor data from the UCI
  Occupancy Detection dataset (Candanedo & Feldheim), ~16 days at ~1-minute
  resolution, resampled to 15-minute intervals. Source:
  https://github.com/LuisM78/Occupancy-detection-data
- **Energy consumption** — synthetic, calibrated (not from a real meter). We
  tried to source real per-building electricity data from the Building Data
  Genome Project 2, but its meter CSVs are stored via Git LFS and were not
  reachable from this environment; if you can pull that file (or your own
  institution's meter data) later, swap it in — the schema below is unchanged.
  The synthetic generator uses a baseline load + an occupancy-driven load +
  a temperature-driven HVAC term + noise, with ~1.5% of readings replaced by
  injected spikes (2.5x-4x normal) as labeled anomalies for evaluating the
  anomaly-detection model.
- **Timetable** — synthetic weekly schedule for room-a, independent of the
  sensor data, used to compare scheduled vs. actual use.
- **Overcrowding proxy** — the dataset has no headcount, only a binary
  occupied/not-occupied flag. CO2 concentration is used as the established
  proxy for occupant density (more people breathing in a room raises CO2);
  `overcrowded` = occupied AND CO2 > 1000 ppm, a standard indoor-air-quality
  threshold for poor ventilation/crowding.

## `readings` documents (path: `rooms/{room_id}/readings/{timestamp}`)

| Field | Type | Meaning |
| --- | --- | --- |
| timestamp | string (ISO 8601) | 15-minute interval start |
| room_id | string | e.g. "room-a" |
| temperature_c | float | real sensor reading |
| humidity_pct | float | real sensor reading |
| co2_ppm | float | real sensor reading |
| occupied | bool | real sensor reading |
| crowding_index | float [0-1] | CO2 min-max scaled across the dataset |
| overcrowded | bool | occupied AND co2_ppm > 1000 |
| energy_kwh | float | synthetic, see above |
| energy_anomaly | bool | ground-truth label for injected anomalies (evaluation only, not a model input) |
| source | string | "seed_real" (sensor fields) / "seed_synthetic" (energy) — a manually-added reading later will be tagged "manual" |

## `timetable` documents (path: `rooms/{room_id}/timetable/{entry_id}`)

| Field | Type | Meaning |
| --- | --- | --- |
| room_id | string | e.g. "room-a" |
| day_of_week | string | "Mon".."Sun" |
| start_time / end_time | string "HH:MM" | scheduled slot |
| subject | string | synthetic class/lab name |
| capacity | int | room's nominal capacity |
| expected_headcount | int | planned attendance for that slot |
