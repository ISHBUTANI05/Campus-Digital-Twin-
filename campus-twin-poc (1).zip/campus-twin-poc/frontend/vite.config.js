import react from '@vitejs/plugin-react'
import { defineConfig, loadEnv } from 'vite'
import { createTwinAi, twinAiMiddleware } from './server/twinAi.js'

// Serves /api/twin/* from the dev and preview servers. ANTHROPIC_API_KEY has
// no VITE_ prefix on purpose: it stays on the server and is never bundled.
function twinAiPlugin(env) {
  const twinAi = createTwinAi({
    apiKey: env.ANTHROPIC_API_KEY || process.env.ANTHROPIC_API_KEY,
    model: env.TWIN_AI_MODEL || 'claude-opus-5',
  })
  const mount = (server) => {
    server.middlewares.use(twinAiMiddleware(twinAi))
    console.log(
      twinAi.enabled
        ? `  ➜  Twin AI: Claude (${twinAi.model}) enabled`
        : '  ➜  Twin AI: no ANTHROPIC_API_KEY, using the built-in offline brain'
    )
  }
  return { name: 'twin-ai', configureServer: mount, configurePreviewServer: mount }
}

// https://vite.dev/config/
export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, process.cwd(), '')
  return {
    plugins: [react(), twinAiPlugin(env)],
  }
})
