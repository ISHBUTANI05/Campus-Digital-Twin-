// Server-side Claude integration for the twin. Runs inside the Vite dev /
// preview server (see vite.config.js), so the API key never reaches the
// browser and there is no CORS problem. The browser sends the live twin
// snapshot with every request; Claude answers only from that snapshot.
import Anthropic from "@anthropic-ai/sdk";
import { betaZodOutputFormat } from "@anthropic-ai/sdk/helpers/beta/zod";
import { z } from "zod";

const ACTION_TYPES = ["ventilation", "relocate", "energy", "maintenance", "schedule", "comfort"];

const AnswerSchema = z.object({
  answer: z.string().describe("The reply shown to the user. Plain text; short '- ' bullets allowed; **bold** allowed."),
  highlight_room_ids: z.array(z.string()).describe("Room ids from the snapshot that the answer is about."),
  follow_ups: z.array(z.string()).describe("Up to 3 short follow-up questions the user might ask next."),
});

const AdviceSchema = z.object({
  summary: z.string().describe("One or two sentences on the overall building situation right now."),
  actions: z.array(
    z.object({
      priority: z.enum(["critical", "high", "medium", "low"]),
      room_id: z.string(),
      action_type: z.enum(ACTION_TYPES),
      title: z.string().describe("Imperative, under 60 characters."),
      rationale: z.string().describe("Why, citing the specific snapshot numbers."),
      expected_impact: z.string().describe("What should change if this is done."),
      target_room_id: z.string().nullable().describe("For relocate actions: the destination room id. Otherwise null."),
    })
  ),
});

const SYSTEM_BASE = `You are Twin Copilot, the AI operator for a campus building digital twin (6 rooms).
Each request includes a JSON snapshot of the twin at this moment: per-room latest sensor readings (occupancy, CO2, temperature, Wi-Fi devices, energy), model outputs (crowding index, overcrowded flag, energy anomaly with z-score, utilization over the last 12 h, next-hour energy forecast), 1-hour trends, the 12-hour peak, and the current and next timetable slot.

Rules:
- Ground every number and claim in the snapshot. Never invent readings, rooms, or schedule entries. If the snapshot can't answer something, say what data is missing.
- Refer to rooms by name. Only use room ids that appear in the snapshot.
- Thresholds used by the twin: CO2 above 1000 ppm while occupied is poor air / overcrowding risk; crowding index above 85% is overcrowded; energy z-score above 2.5 is an anomaly; comfortable temperature is 21-26 °C.
- In this demo every room is simulated. CS Lab 1 is modelled on the real UCI Occupancy Detection dataset (temperature, humidity, CO2, occupancy), which also backs the single-room backend path; energy is synthetic but calibrated. Mention this only if asked about data provenance.`;

const ASK_SYSTEM = `${SYSTEM_BASE}

You are answering questions in a chat panel. Lead with the direct answer. Keep it to 1-4 sentences or up to 5 short bullets. When the question implies a decision ("what should we do", "where should the class go"), recommend a concrete next step and say why. Put the rooms the answer is about in highlight_room_ids so the floor plan can light them up.`;

const ADVISE_SYSTEM = `${SYSTEM_BASE}

You are deciding the facilities team's next steps. Return between 2 and 6 actions, most urgent first. Each action must be something an operator can do now (ventilate, relocate a class, shut off idle load, inspect equipment, adjust HVAC, reschedule) and must cite the numbers that justify it. For a relocate action, pick a target room that has enough capacity and is not busy, and set target_room_id. Do not invent problems: if a room is fine, leave it out.`;

export function createTwinAi({ apiKey, model }) {
  const client = apiKey ? new Anthropic({ apiKey }) : null;

  async function call(system, messages, schema, effort) {
    const response = await client.beta.messages.parse({
      model,
      max_tokens: 16000,
      betas: ["server-side-fallback-2026-07-01"],
      fallbacks: "default",
      output_config: { effort, format: betaZodOutputFormat(schema) },
      system,
      messages,
    });
    if (response.stop_reason === "refusal") throw new Error("Model declined the request");
    if (!response.parsed_output) throw new Error(`No structured output (stop_reason=${response.stop_reason})`);
    return response.parsed_output;
  }

  return {
    enabled: !!client,
    model,

    async ask({ question, history = [], snapshot }) {
      const messages = [];
      for (const turn of history.slice(-8)) {
        messages.push({ role: turn.role === "user" ? "user" : "assistant", content: turn.text });
      }
      messages.push({
        role: "user",
        content: `<twin_snapshot>\n${JSON.stringify(snapshot)}\n</twin_snapshot>\n\n${question}`,
      });
      return call(ASK_SYSTEM, messages, AnswerSchema, "low");
    },

    async advise({ snapshot }) {
      const messages = [
        {
          role: "user",
          content: `<twin_snapshot>\n${JSON.stringify(snapshot)}\n</twin_snapshot>\n\nDecide the next steps for the facilities team.`,
        },
      ];
      return call(ADVISE_SYSTEM, messages, AdviceSchema, "medium");
    },
  };
}

function readJson(req) {
  return new Promise((resolve, reject) => {
    let body = "";
    req.on("data", (chunk) => {
      body += chunk;
      if (body.length > 1_000_000) reject(new Error("Body too large"));
    });
    req.on("end", () => {
      try {
        resolve(body ? JSON.parse(body) : {});
      } catch (e) {
        reject(e);
      }
    });
    req.on("error", reject);
  });
}

function send(res, status, payload) {
  res.statusCode = status;
  res.setHeader("Content-Type", "application/json");
  res.end(JSON.stringify(payload));
}

/**
 * Framework-neutral router for the twin AI endpoints:
 * GET /api/twin/status, POST /api/twin/ask, POST /api/twin/advise.
 * Shared by the Vite dev/preview middleware and the Vercel function.
 */
export async function handleTwinRequest(twinAi, { method, path, getBody }) {
  if (path === "/api/twin/status" && method === "GET") {
    return [200, { enabled: twinAi.enabled, model: twinAi.enabled ? twinAi.model : null }];
  }
  if (method !== "POST" || !["/api/twin/ask", "/api/twin/advise"].includes(path)) {
    return [404, { error: "Not found" }];
  }
  if (!twinAi.enabled) return [503, { error: "AI not configured (set ANTHROPIC_API_KEY)" }];

  try {
    const body = (await getBody()) || {};
    if (!body.snapshot) return [400, { error: "snapshot is required" }];
    if (path === "/api/twin/ask") {
      if (!body.question?.trim()) return [400, { error: "question is required" }];
      return [200, await twinAi.ask(body)];
    }
    return [200, await twinAi.advise(body)];
  } catch (err) {
    if (err instanceof Anthropic.AuthenticationError) {
      console.error("[twin-ai] invalid ANTHROPIC_API_KEY");
      return [502, { error: "Invalid API key" }];
    }
    if (err instanceof Anthropic.RateLimitError) return [429, { error: "Rate limited" }];
    if (err instanceof Anthropic.APIError) {
      console.error(`[twin-ai] API error ${err.status}:`, err.message);
      return [502, { error: `Claude API error ${err.status}` }];
    }
    console.error("[twin-ai]", err);
    return [500, { error: err.message }];
  }
}

/** Connect-style middleware for the Vite dev and preview servers. */
export function twinAiMiddleware(twinAi) {
  return async (req, res, next) => {
    const path = req.url.split("?")[0];
    if (!path.startsWith("/api/twin/")) return next();
    const [status, payload] = await handleTwinRequest(twinAi, {
      method: req.method,
      path,
      getBody: () => readJson(req),
    });
    send(res, status, payload);
  };
}
