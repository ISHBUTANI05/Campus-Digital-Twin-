import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useAuth } from "./context/AuthContext";
import { DemoStoreProvider } from "./store/DemoStore";
import Login from "./pages/Login";
import Overview from "./pages/Overview";
import RoomDetail from "./pages/RoomDetail";

export default function App() {
  const { user } = useAuth();

  if (user === undefined) return <div className="page-loading">Loading…</div>;
  if (!user) return <Login />;

  return (
    <DemoStoreProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Overview />} />
          <Route path="/rooms/:roomId" element={<RoomDetail />} />
        </Routes>
      </BrowserRouter>
    </DemoStoreProvider>
  );
}
