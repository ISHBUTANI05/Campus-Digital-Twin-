import { useEffect, useState } from "react";
import {
  collection,
  doc,
  onSnapshot,
  orderBy,
  query,
  limit,
  setDoc,
} from "firebase/firestore";
import { db } from "../firebase";

/** Live latest reading for a room — updates instantly on any write (seed, manual, or a real sensor later). */
export function useLatestReading(roomId) {
  const [reading, setReading] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, "rooms", roomId, "readings"),
      orderBy("timestamp", "desc"),
      limit(1)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        setReading(snap.empty ? null : snap.docs[0].data());
        setLoading(false);
      },
      (err) => {
        console.error("useLatestReading:", err);
        setLoading(false);
      }
    );
    return unsub;
  }, [roomId]);

  return { reading, loading };
}

/** Live history for the chart — last `take` readings, oldest first. */
export function useReadingsHistory(roomId, take = 96) {
  const [readings, setReadings] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const q = query(
      collection(db, "rooms", roomId, "readings"),
      orderBy("timestamp", "desc"),
      limit(take)
    );
    const unsub = onSnapshot(
      q,
      (snap) => {
        const rows = snap.docs.map((d) => d.data()).reverse(); // oldest first for charting
        setReadings(rows);
        setLoading(false);
      },
      (err) => {
        console.error("useReadingsHistory:", err);
        setLoading(false);
      }
    );
    return unsub;
  }, [roomId, take]);

  return { readings, loading };
}

/** Timetable rarely changes — one-shot live subscription is still fine and simple. */
export function useTimetable(roomId) {
  const [timetable, setTimetable] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "rooms", roomId, "timetable"), orderBy("day_of_week"));
    const unsub = onSnapshot(q, (snap) => setTimetable(snap.docs.map((d) => d.data())));
    return unsub;
  }, [roomId]);

  return timetable;
}

/**
 * The manual "proof lever": writes a reading straight to Firestore, computing
 * the same crowding_index/overcrowded proxy the seed data and backend use, so
 * a manual entry behaves identically to a real one.
 */
export async function addManualReading(roomId, input) {
  const co2 = input.co2_ppm ?? null;
  const occupied = !!input.occupied;
  const timestamp = input.timestamp ?? new Date().toISOString();

  const reading = {
    room_id: roomId,
    timestamp,
    temperature_c: input.temperature_c ?? null,
    humidity_pct: input.humidity_pct ?? null,
    co2_ppm: co2,
    occupied,
    crowding_index: co2 != null ? Math.min(1, Math.max(0, (co2 - 400) / (2000 - 400))) : null,
    overcrowded: occupied && co2 != null && co2 > 1000,
    energy_kwh: input.energy_kwh ?? null,
    energy_anomaly: false, // ground truth unknown for a manual entry; the model decides
    source: "manual",
  };

  await setDoc(doc(db, "rooms", roomId, "readings", timestamp), reading);
  return reading;
}
