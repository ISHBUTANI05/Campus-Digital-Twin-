import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from "react";
import { ROOMS, buildTimetable } from "../mock/rooms";
import { generateAllHistories, occupancyFracFromCo2 } from "../mock/generateHistory";
import { predictAll } from "../mock/predictions";
import { buildSnapshot } from "../lib/snapshot";
import { adviseTwin, askTwin, getAiStatus } from "../lib/twinApi";

const DemoStoreContext = createContext(null);

function makeReading(room, last, patch, source) {
  const occupancy_count = Math.max(0, Math.round(patch.occupancy_count ?? last.occupancy_count));
  const occupied = patch.occupied ?? occupancy_count > 0;
  const co2_ppm = Math.round(patch.co2_ppm ?? last.co2_ppm);
  const crowding_index = Math.min(1, Math.max(0, occupancy_count / room.capacity));
  return {
    room_id: room.id,
    timestamp: new Date().toISOString(),
    occupancy_count,
    capacity: room.capacity,
    occupied,
    co2_ppm,
    temperature_c: Math.round((patch.temperature_c ?? last.temperature_c) * 10) / 10,
    wifi_devices: patch.wifi_devices ?? Math.round(occupancy_count * 0.9),
    energy_kwh: Math.round((patch.energy_kwh ?? last.energy_kwh) * 100) / 100,
    energy_anomaly: false,
    crowding_index,
    overcrowded: crowding_index > 0.85 || (occupied && co2_ppm > 1000),
    source,
  };
}

export function DemoStoreProvider({ children }) {
  const [histories, setHistories] = useState(() => generateAllHistories());
  const roomsById = useMemo(() => Object.fromEntries(ROOMS.map((r) => [r.id, r])), []);
  const timetables = useMemo(() => Object.fromEntries(ROOMS.map((r) => [r.id, buildTimetable(r)])), []);
  const predictions = useMemo(() => predictAll(roomsById, histories), [roomsById, histories]);
  const snapshot = useMemo(
    () => buildSnapshot({ rooms: ROOMS, histories, predictions, timetables }),
    [histories, predictions, timetables]
  );
  // Async handlers read the latest snapshot at call time, not render time.
  const snapshotRef = useRef(snapshot);
  useEffect(() => {
    snapshotRef.current = snapshot;
  }, [snapshot]);

  const [ai, setAi] = useState({ enabled: false, model: null, checked: false });
  const [events, setEvents] = useState([]);
  const [highlight, setHighlight] = useState([]);
  const [messages, setMessages] = useState([]);
  const [asking, setAsking] = useState(false);
  const [advice, setAdvice] = useState(null);
  const [advising, setAdvising] = useState(false);
  const [done, setDone] = useState({}); // action key -> true
  const [stale, setStale] = useState(false); // twin changed since last plan

  useEffect(() => {
    getAiStatus().then((s) => setAi({ ...s, checked: true }));
  }, []);

  const logEvent = useCallback((kind, title, detail) => {
    setEvents((e) => [{ at: new Date(), kind, title, detail }, ...e].slice(0, 30));
  }, []);

  const patchRooms = useCallback(
    (patches, source) => {
      setHistories((prev) => {
        const next = { ...prev };
        for (const [roomId, patch] of Object.entries(patches)) {
          const hist = prev[roomId];
          next[roomId] = [...hist, makeReading(roomsById[roomId], hist[hist.length - 1], patch, source)];
        }
        return next;
      });
      setStale(true);
    },
    [roomsById]
  );

  // The manual "proof lever": append a reading for one room and everything
  // (state, charts, predictions, copilot answers) recomputes immediately.
  const addManualReading = useCallback(
    (roomId, input) => {
      const room = roomsById[roomId];
      const occupancy_count = input.occupied
        ? Math.round((input.co2_ppm ? occupancyFracFromCo2(input.co2_ppm) : 0.6) * room.capacity)
        : 0;
      patchRooms({ [roomId]: { ...input, occupancy_count, occupied: !!input.occupied } }, "manual");
      logEvent("manual", `Manual reading · ${room.name}`, `CO2 ${input.co2_ppm} ppm, ${input.temperature_c} °C, ${input.energy_kwh} kWh`);
    },
    [roomsById, patchRooms, logEvent]
  );

  /** Carry out a recommended action on the twin and show its effect. */
  const applyAction = useCallback(
    (action) => {
      const snap = snapshotRef.current;
      const r = snap.rooms.find((x) => x.id === action.room_id);
      if (!r) return;
      const l = r.latest;
      const patches = {};
      let detail = "";

      switch (action.action_type) {
        case "ventilation": {
          const co2 = Math.max(550, Math.min(950, Math.round(l.co2_ppm * 0.6)));
          patches[r.id] = { co2_ppm: co2, temperature_c: l.temperature_c - 0.4 };
          detail = `CO2 ${l.co2_ppm} → ${co2} ppm`;
          break;
        }
        case "relocate": {
          const t = snap.rooms.find((x) => x.id === action.target_room_id);
          if (!t) return;
          const keep = Math.floor(r.capacity * 0.6);
          const moved = Math.max(0, Math.min(l.occupancy - keep, t.capacity - t.latest.occupancy));
          const occA = l.occupancy - moved;
          const occB = t.latest.occupancy + moved;
          patches[r.id] = {
            occupancy_count: occA,
            co2_ppm: Math.min(l.co2_ppm, 420 + (occA / r.capacity) * 900),
            energy_kwh: Math.max(0.4, l.energy_kwh - (moved / r.capacity) * 2.2),
          };
          patches[t.id] = {
            occupancy_count: occB,
            co2_ppm: Math.max(t.latest.co2_ppm, 420 + (occB / t.capacity) * 900),
            energy_kwh: t.latest.energy_kwh + (moved / t.capacity) * 2.2,
          };
          detail = `${moved} people moved · ${r.name} ${l.occupancy} → ${occA}, ${t.name} ${t.latest.occupancy} → ${occB}`;
          break;
        }
        case "energy":
        case "maintenance": {
          const normal = l.occupied
            ? 0.4 + (l.occupancy / r.capacity) * 2.2
            : (r.idle_energy_baseline_kwh ?? 0.45);
          const kwh = Math.min(l.energy_kwh, normal);
          patches[r.id] = { energy_kwh: kwh };
          detail = `Energy ${l.energy_kwh} → ${kwh.toFixed(2)} kWh`;
          break;
        }
        case "comfort": {
          patches[r.id] = { temperature_c: 23.5 };
          detail = `Temperature ${l.temperature_c} → 23.5 °C`;
          break;
        }
        default:
          detail = "Logged for the operations team";
      }

      if (Object.keys(patches).length) patchRooms(patches, "action");
      setDone((d) => ({ ...d, [`${action.room_id}:${action.action_type}:${action.title}`]: true }));
      logEvent("action", action.title, detail);
    },
    [patchRooms, logEvent]
  );

  const refreshAdvice = useCallback(async () => {
    setAdvising(true);
    try {
      const out = await adviseTwin({ snapshot: snapshotRef.current, aiEnabled: ai.enabled });
      setAdvice({ ...out, at: new Date() });
      setDone({});
      setStale(false);
    } finally {
      setAdvising(false);
    }
  }, [ai.enabled]);

  // Plan once when we know whether Claude is available.
  useEffect(() => {
    if (ai.checked) refreshAdvice();
  }, [ai.checked, refreshAdvice]);

  const ask = useCallback(
    async (question) => {
      const text = question.trim();
      if (!text || asking) return;
      const history = messages.map((m) => ({ role: m.role, text: m.text }));
      setMessages((m) => [...m, { role: "user", text }]);
      setAsking(true);
      try {
        const out = await askTwin({ question: text, history, snapshot: snapshotRef.current, aiEnabled: ai.enabled });
        setMessages((m) => [
          ...m,
          { role: "assistant", text: out.answer, source: out.source, followUps: out.follow_ups, rooms: out.highlight_room_ids },
        ]);
        setHighlight(out.highlight_room_ids || []);
      } finally {
        setAsking(false);
      }
    },
    [messages, asking, ai.enabled]
  );

  const value = {
    rooms: ROOMS,
    roomsById,
    histories,
    timetables,
    predictions,
    snapshot,
    ai,
    events,
    highlight,
    setHighlight,
    messages,
    asking,
    ask,
    clearChat: () => { setMessages([]); setHighlight([]); },
    advice,
    advising,
    refreshAdvice,
    done,
    stale,
    applyAction,
    addManualReading,
  };

  return <DemoStoreContext.Provider value={value}>{children}</DemoStoreContext.Provider>;
}

export function useDemoStore() {
  return useContext(DemoStoreContext);
}
