// Lightweight, explainable scoring that stands in for the trained models
// (gradient-boosting overcrowding classifier, Isolation Forest anomaly
// detector) described in the proposal — same signals, computed client-side
// for a zero-latency demo. Swapping in the real trained models later doesn't
// change any UI code: they'd just replace these functions' outputs.

function mean(arr) { return arr.reduce((a, b) => a + b, 0) / (arr.length || 1); }
function std(arr) {
  const m = mean(arr);
  return Math.sqrt(mean(arr.map((v) => (v - m) ** 2)));
}

/** Energy a room "should" draw for its occupancy and temperature (same load model as the generator). */
export function expectedEnergy(room, reading) {
  return 0.4 + (reading.occupancy_count / room.capacity) * 2.2 + Math.abs(reading.temperature_c - 22) * 0.05;
}

export function predictRoom(room, history) {
  const latest = history[history.length - 1];
  // Occupancy-aware anomaly score: z-score of (actual - expected) energy, so a
  // busy daytime room isn't flagged just for using more than it did at night.
  const residuals = history.map((r) => r.energy_kwh - expectedEnergy(room, r));
  const baseline = residuals.slice(0, -1);
  const resMean = mean(baseline);
  const resStd = Math.max(std(baseline), 0.1);
  const energyZ = (residuals[residuals.length - 1] - resMean) / resStd;

  const occupiedSlots = history.filter((r) => r.occupied).length;
  const utilization = Math.round((occupiedSlots / history.length) * 100);

  // next-hour energy forecast: last value + average trend of the last 4 steps
  const tail = history.slice(-4);
  const trend = tail.length > 1 ? (tail[tail.length - 1].energy_kwh - tail[0].energy_kwh) / tail.length : 0;
  const forecastEnergyKwh = Math.max(0, latest.energy_kwh + trend * 4);

  return {
    room_id: room.id,
    overcrowded: latest.overcrowded,
    crowding_index: latest.crowding_index,
    energy_anomaly: latest.energy_anomaly || energyZ > 2.5,
    energy_z: Math.round(energyZ * 100) / 100,
    utilization_pct: utilization,
    forecast_energy_kwh: Math.round(forecastEnergyKwh * 100) / 100,
  };
}

export function predictAll(roomsById, historiesById) {
  const out = {};
  for (const id of Object.keys(historiesById)) {
    out[id] = predictRoom(roomsById[id], historiesById[id]);
  }
  return out;
}

/** Building-wide ranking used for "peak usage periods" style answers. */
export function rankByCrowding(rooms, predictions) {
  return [...rooms]
    .map((r) => ({ room: r, pred: predictions[r.id] }))
    .sort((a, b) => b.pred.crowding_index - a.pred.crowding_index);
}
