// Generates a realistic-looking last-12-hours history per room, at 15-minute
// intervals, ending "now". Two rooms are deliberately staged so the demo has
// something to point at immediately without touching the manual-entry form:
//   - Electronics Lab (room-c): currently overcrowded
//   - Seminar Hall (room-d): currently has an energy anomaly spike
import { ROOMS } from "./rooms";

function seeded(seedStr) {
  // small deterministic PRNG so the "random" demo data is stable across reloads
  let h = 0;
  for (let i = 0; i < seedStr.length; i++) h = (h * 31 + seedStr.charCodeAt(i)) >>> 0;
  return () => {
    h = (h * 1664525 + 1013904223) >>> 0;
    return h / 4294967296;
  };
}

// CO2 rise above outdoor (~420 ppm) when a room is at full capacity.
export const CO2_FULL_ROOM_RISE = 1100;
export const occupancyFracFromCo2 = (co2) => Math.min(1, Math.max(0.05, (co2 - 420) / CO2_FULL_ROOM_RISE));

const INTERVALS = 48; // 12 hours at 15-min steps
const STEP_MIN = 15;

export function generateRoomHistory(room, now = new Date()) {
  const rand = seeded(room.id);
  const readings = [];

  for (let i = INTERVALS; i >= 0; i--) {
    const ts = new Date(now.getTime() - i * STEP_MIN * 60 * 1000);
    const hour = ts.getHours() + ts.getMinutes() / 60;

    // diurnal occupancy curve: busy 9-5, peak around 11 and 3
    const dayShape = Math.max(0, Math.sin(((hour - 8) / 10) * Math.PI));
    const isLast = i === 0;

    let occupancyFrac = dayShape * (0.5 + 0.5 * rand()) ;
    occupancyFrac = Math.min(1.05, Math.max(0, occupancyFrac + (rand() - 0.5) * 0.15));

    // stage room-c as overcrowded right now
    if (room.id === "room-c" && isLast) occupancyFrac = 0.97;

    const occupancy_count = Math.round(occupancyFrac * room.capacity);
    const occupied = occupancy_count > 0;
    const co2_ppm = 420 + occupancyFrac * CO2_FULL_ROOM_RISE + (rand() - 0.5) * 60;
    const temperature_c = 23 + occupancyFrac * 2.5 + Math.sin(hour / 3) * 1.2 + (rand() - 0.5) * 0.6;
    const wifi_devices = Math.round(occupancy_count * (0.8 + rand() * 0.4));

    let energy_kwh = 0.4 + occupancyFrac * 2.2 + Math.abs(temperature_c - 22) * 0.05 + (rand() - 0.5) * 0.15;
    let energy_anomaly = false;
    if (room.id === "room-d" && isLast) {
      energy_kwh *= 3.2;
      energy_anomaly = true;
    }

    readings.push({
      room_id: room.id,
      timestamp: ts.toISOString(),
      occupancy_count,
      capacity: room.capacity,
      occupied,
      co2_ppm: Math.round(co2_ppm),
      temperature_c: Math.round(temperature_c * 10) / 10,
      wifi_devices,
      energy_kwh: Math.round(energy_kwh * 100) / 100,
      energy_anomaly,
      crowding_index: Math.min(1, Math.max(0, occupancyFrac)),
      overcrowded: occupancyFrac > 0.85,
      source: room.real ? "seed_real+synthetic" : "synthetic",
    });
  }
  return readings;
}

export function generateAllHistories(now = new Date()) {
  const map = {};
  for (const room of ROOMS) map[room.id] = generateRoomHistory(room, now);
  return map;
}
