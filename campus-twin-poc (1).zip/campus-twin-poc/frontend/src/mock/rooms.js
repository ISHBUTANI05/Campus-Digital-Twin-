export const ROOMS = [
  { id: "room-a", name: "CS Lab 1", type: "lab", capacity: 40, real: true },
  { id: "room-b", name: "Lecture Hall 1", type: "classroom", capacity: 80 },
  { id: "room-c", name: "Electronics Lab", type: "lab", capacity: 35 },
  { id: "room-d", name: "Seminar Hall", type: "hall", capacity: 100 },
  { id: "room-e", name: "Lecture Hall 2", type: "classroom", capacity: 60 },
  { id: "room-f", name: "Project Lab", type: "lab", capacity: 30 },
];

const SUBJECTS = {
  lab: ["Data Structures Lab", "Networks Lab", "Mini Project", "Elective Lab"],
  classroom: ["Operating Systems", "Digital Electronics", "Elective: ML", "Compiler Design"],
  hall: ["Dept. Seminar", "Guest Lecture", "Project Reviews", "Placement Talk"],
};

export function buildTimetable(room) {
  const slots = [
    ["09:00", "10:30"],
    ["10:45", "12:15"],
    ["13:15", "14:45"],
    ["15:00", "16:30"],
  ];
  const subs = SUBJECTS[room.type];
  const rows = [];
  ["Mon", "Tue", "Wed", "Thu", "Fri"].forEach((day, di) => {
    slots.forEach(([start, end], si) => {
      rows.push({
        room_id: room.id,
        day_of_week: day,
        start_time: start,
        end_time: end,
        subject: subs[(di + si) % subs.length],
        capacity: room.capacity,
        expected_headcount: Math.round(room.capacity * (0.5 + 0.4 * ((di + si) % 3) / 2)),
      });
    });
  });
  return rows;
}
