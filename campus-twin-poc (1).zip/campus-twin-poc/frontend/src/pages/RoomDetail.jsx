import { useMemo, useState } from "react";
import { useParams, Link } from "react-router-dom";
import { useDemoStore } from "../store/DemoStore";
import { heat, STATUS_LABEL } from "../lib/colors";
import { occupancyFracFromCo2 } from "../mock/generateHistory";
import { predictRoom } from "../mock/predictions";
import TopBar from "../components/TopBar";
import LineChart from "../components/LineChart";
import Copilot from "../components/Copilot";
import ActionsPanel from "../components/ActionsPanel";
import Ring from "../components/Ring";
import Icon from "../components/Icon";

const DAY_START = 8 * 60;
const DAY_END = 18 * 60;
const toMin = (hhmm) => {
  const [h, m] = hhmm.split(":").map(Number);
  return h * 60 + m;
};

function Gauge({ icon, label, value, unit, sub, ring, tone }) {
  return (
    <div className="panel gauge">
      <div className="kpi-label" style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <Icon name={icon} size={13} /> {label}
      </div>
      <div className="gauge-row">
        {ring != null && <Ring value={ring} size={48} stroke={5} color={tone} />}
        <div>
          <div className="kpi-value" style={{ fontSize: "1.35rem", color: tone }}>{value}<small>{unit}</small></div>
          {sub && <div className="kpi-sub">{sub}</div>}
        </div>
      </div>
    </div>
  );
}

function DayTimeline({ timetable, day }) {
  const now = new Date();
  const nowMin = now.getHours() * 60 + now.getMinutes();
  const slots = timetable.filter((t) => t.day_of_week === day);
  const pos = (m) => `${((Math.min(DAY_END, Math.max(DAY_START, m)) - DAY_START) / (DAY_END - DAY_START)) * 100}%`;
  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title"><Icon name="calendar" size={16} /> Today · {day}</h2>
      </div>
      <div className="panel-body">
        {slots.length === 0 ? (
          <div className="muted">No classes scheduled today.</div>
        ) : (
          <div className="timeline">
            <div className="timeline-track" />
            {slots.map((s) => {
              const a = toMin(s.start_time);
              const b = toMin(s.end_time);
              const live = nowMin >= a && nowMin < b;
              return (
                <div
                  key={s.start_time}
                  className={`timeline-slot ${live ? "now" : ""}`}
                  style={{ left: pos(a), width: `calc(${pos(b)} - ${pos(a)})` }}
                  title={`${s.subject} ${s.start_time}–${s.end_time}, ${s.expected_headcount} expected`}
                >
                  {s.subject}
                  <small>{s.start_time} · {s.expected_headcount}/{s.capacity}</small>
                </div>
              );
            })}
            {nowMin >= DAY_START && nowMin <= DAY_END && <div className="timeline-now" style={{ left: pos(nowMin) }} />}
            <div className="timeline-axis">
              {[8, 10, 12, 14, 16, 18].map((h) => <span key={h}>{String(h).padStart(2, "0")}:00</span>)}
            </div>
          </div>
        )}
      </div>
    </section>
  );
}

function Slider({ label, value, min, max, step, unit, onChange }) {
  const p = ((value - min) / (max - min)) * 100;
  return (
    <div className="slider-row">
      <label>{label}</label>
      <input type="range" min={min} max={max} step={step} value={value} style={{ "--p": `${p}%` }} onChange={(e) => onChange(Number(e.target.value))} />
      <output>{value}{unit}</output>
    </div>
  );
}

function Simulator({ room, history }) {
  const { addManualReading } = useDemoStore();
  const latest = history[history.length - 1];
  const [form, setForm] = useState({ occupied: true, co2_ppm: 1200, temperature_c: 24, energy_kwh: 2.5 });
  const [flash, setFlash] = useState(false);

  // preview what the twin's models would say about this reading
  const preview = useMemo(() => {
    const occ = form.occupied ? Math.round(occupancyFracFromCo2(form.co2_ppm) * room.capacity) : 0;
    const reading = { ...history[history.length - 1], ...form, occupancy_count: occ, energy_anomaly: false, overcrowded: false };
    const p = predictRoom(room, [...history, reading]);
    return {
      occ,
      overcrowded: occ / room.capacity > 0.85 || (form.occupied && form.co2_ppm > 1000),
      anomaly: p.energy_anomaly,
      z: p.energy_z.toFixed(2),
    };
  }, [form, history, room]);

  const set = (k) => (v) => setForm((f) => ({ ...f, [k]: v }));
  const submit = () => {
    addManualReading(room.id, form);
    setFlash(true);
    setTimeout(() => setFlash(false), 1200);
  };

  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title"><Icon name="sliders" size={16} /> What-if sensor lever</h2>
        <span className="muted" style={{ fontSize: "0.75rem" }}>last real: {latest.co2_ppm} ppm · {latest.energy_kwh} kWh</span>
      </div>
      <div className="panel-body sim">
        <label className="toggle">
          <input type="checkbox" checked={form.occupied} onChange={(e) => set("occupied")(e.target.checked)} />
          <span className="track" /> Room occupied
        </label>
        <Slider label="CO2" value={form.co2_ppm} min={400} max={2500} step={10} unit=" ppm" onChange={set("co2_ppm")} />
        <Slider label="Temperature" value={form.temperature_c} min={16} max={32} step={0.1} unit=" °C" onChange={set("temperature_c")} />
        <Slider label="Energy" value={form.energy_kwh} min={0} max={8} step={0.1} unit=" kWh" onChange={set("energy_kwh")} />
        <div className="sim-preview">
          Twin will read: <b className="num">{preview.occ}/{room.capacity} people</b>
          <span className={`pill ${preview.overcrowded ? "pill-critical" : "pill-good"}`}>{preview.overcrowded ? "Overcrowded" : "Crowding OK"}</span>
          <span className={`pill ${preview.anomaly ? "pill-warning" : "pill-good"}`}>{preview.anomaly ? `Energy anomaly (z ${preview.z})` : `Energy OK (z ${preview.z})`}</span>
        </div>
        <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
          <button className="btn btn-primary" onClick={submit}><Icon name="activity" size={15} /> Push reading to twin</button>
          {flash && <span className="applied"><Icon name="check" size={15} /> Twin updated</span>}
        </div>
      </div>
    </section>
  );
}

export default function RoomDetail() {
  const { roomId } = useParams();
  const { roomsById, histories, timetables, snapshot } = useDemoStore();
  const room = roomsById[roomId];
  const history = histories[roomId];
  const snap = snapshot.rooms.find((r) => r.id === roomId);

  const series = useMemo(() => {
    if (!history) return {};
    const label = (r) => new Date(r.timestamp).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
    return {
      occ: history.map((r) => ({ y: r.occupancy_count, label: label(r) })),
      co2: history.map((r) => ({ y: r.co2_ppm, label: label(r) })),
      energy: history.map((r) => ({ y: r.energy_kwh, label: label(r) })),
    };
  }, [history]);

  if (!room) {
    return (
      <div className="shell">
        <TopBar />
        <p>Unknown room. <Link to="/" className="link-button">Back to overview</Link></p>
      </div>
    );
  }

  const l = snap.latest;
  const p = snap.predictions;
  const co2Tone = l.co2_ppm > 1000 ? "var(--crit)" : l.co2_ppm > 800 ? "var(--warn)" : "var(--good)";
  const tempTone = l.temperature_c > 26 || l.temperature_c < 20 ? "var(--warn)" : "var(--accent-2)";

  return (
    <div className="shell">
      <TopBar />
      <Link to="/" className="back-link"><Icon name="arrowLeft" size={15} /> Building overview</Link>
      <div className="page-head">
        <div>
          <div className="eyebrow">{room.type} · capacity {room.capacity}</div>
          <h1 style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            {room.name}
            <span className={`pill pill-${snap.status}`}>{STATUS_LABEL[snap.status]}</span>
            {room.real && <span className="pill pill-ai">UCI-based room</span>}
          </h1>
          <p>Last reading {l.at} · {snap.data_source}</p>
        </div>
      </div>

      {p.overcrowded && (
        <div className="alert-banner alert-critical">
          <Icon name="alert" size={20} />
          <div><b>Overcrowding predicted.</b> {l.occupancy}/{room.capacity} occupants ({p.crowding_pct}%), CO2 {l.co2_ppm} ppm.</div>
        </div>
      )}
      {p.energy_anomaly && (
        <div className="alert-banner alert-warning">
          <Icon name="bolt" size={20} />
          <div><b>Abnormal energy consumption.</b> {l.energy_kwh} kWh, z-score {p.energy_z} above what its occupancy explains.</div>
        </div>
      )}

      <div className="main-grid">
        <div className="col">
          <div className="gauges">
            <Gauge icon="users" label="Occupancy" value={l.occupancy} unit={`/${room.capacity}`} sub={`${p.crowding_pct}% crowding`} ring={p.crowding_pct / 100} tone={heat(p.crowding_pct / 100)} />
            <Gauge icon="wind" label="CO2" value={l.co2_ppm} unit="ppm" sub={`${snap.trend_1h.co2_change_ppm >= 0 ? "+" : ""}${snap.trend_1h.co2_change_ppm} in 1 h`} ring={(l.co2_ppm - 400) / 1600} tone={co2Tone} />
            <Gauge icon="thermo" label="Temperature" value={l.temperature_c} unit="°C" sub="comfort 21–26 °C" tone={tempTone} />
            <Gauge icon="bolt" label="Energy" value={l.energy_kwh} unit="kWh" sub={`next hr ${p.forecast_next_hour_kwh} kWh`} tone={p.energy_anomaly ? "var(--warn)" : "var(--text)"} />
            <Gauge icon="wifi" label="Wi-Fi devices" value={l.wifi_devices} unit="" sub="connected now" tone="var(--text)" />
            <Gauge icon="activity" label="Utilization" value={p.utilization_pct_12h} unit="%" sub="last 12 hours" ring={p.utilization_pct_12h / 100} tone="var(--accent)" />
          </div>

          <section className="panel">
            <div className="panel-head"><h2 className="panel-title"><Icon name="activity" size={16} /> Last 12 hours</h2></div>
            <div className="panel-body charts">
              <LineChart title="Occupancy" unit="people" points={series.occ} colorVar="--accent" decimals={0} />
              <LineChart title="CO2" unit="ppm" points={series.co2} colorVar="--accent-2" threshold={1000} decimals={0} />
              <LineChart title="Energy" unit="kWh" points={series.energy} colorVar="--warn" decimals={2} />
            </div>
          </section>

          <DayTimeline timetable={timetables[roomId]} day={snap.schedule.day} />
          <ActionsPanel roomId={roomId} />
          <Simulator room={room} history={history} />
        </div>
        <div className="col sticky-col">
          <Copilot
            suggestions={[
              `How is ${room.name} doing?`,
              `Why is ${room.name} flagged?`,
              `What should we do in ${room.name}?`,
              `When is the next class in ${room.name}?`,
            ]}
          />
        </div>
      </div>
    </div>
  );
}
