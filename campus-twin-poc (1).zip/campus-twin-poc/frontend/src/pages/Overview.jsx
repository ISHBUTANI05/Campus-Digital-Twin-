import { Link } from "react-router-dom";
import { useDemoStore } from "../store/DemoStore";
import { heat, STATUS_LABEL } from "../lib/colors";
import TopBar from "../components/TopBar";
import FloorPlan from "../components/FloorPlan";
import Copilot from "../components/Copilot";
import ActionsPanel from "../components/ActionsPanel";
import EventFeed from "../components/EventFeed";
import Ring from "../components/Ring";
import Icon from "../components/Icon";

function Kpis() {
  const { snapshot } = useDemoStore();
  const b = snapshot.building;
  const alerts = snapshot.rooms.filter((r) => r.status !== "good").length;
  const avgCo2 = Math.round(snapshot.rooms.reduce((s, r) => s + r.latest.co2_ppm, 0) / snapshot.rooms.length);
  const energyDelta = b.energy_forecast_next_hour_kwh - b.energy_now_kwh;
  return (
    <div className="kpis">
      <div className="panel kpi">
        <Ring value={b.occupancy_pct / 100} color={heat(b.occupancy_pct / 100)} label={`${b.occupancy_pct}%`} />
        <div>
          <div className="kpi-label">Building occupancy</div>
          <div className="kpi-value">{b.occupancy}<small>/ {b.capacity}</small></div>
          <div className="kpi-sub">people across {b.rooms} rooms</div>
        </div>
      </div>
      <div className="panel kpi">
        <div className="kpi-icon" style={{ "--tone": alerts ? "var(--crit)" : "var(--good)" }}><Icon name="alert" size={24} /></div>
        <div>
          <div className="kpi-label">Active alerts</div>
          <div className="kpi-value" style={{ color: alerts ? "var(--crit)" : "var(--good)" }}>{alerts}</div>
          <div className="kpi-sub">
            {b.overcrowded_rooms.length} crowding · {b.energy_anomaly_rooms.length} energy
          </div>
        </div>
      </div>
      <div className="panel kpi">
        <div className="kpi-icon" style={{ "--tone": "var(--warn)" }}><Icon name="bolt" size={24} /></div>
        <div>
          <div className="kpi-label">Energy now</div>
          <div className="kpi-value">{b.energy_now_kwh.toFixed(1)}<small>kWh</small></div>
          <div className="kpi-sub">
            next hour {b.energy_forecast_next_hour_kwh.toFixed(1)} kWh{" "}
            <span style={{ color: energyDelta > 0 ? "var(--warn)" : "var(--good)" }}>
              ({energyDelta >= 0 ? "▲" : "▼"} {Math.abs(energyDelta).toFixed(1)})
            </span>
          </div>
        </div>
      </div>
      <div className="panel kpi">
        <div className="kpi-icon" style={{ "--tone": avgCo2 > 1000 ? "var(--crit)" : "var(--accent-2)" }}><Icon name="wind" size={24} /></div>
        <div>
          <div className="kpi-label">Avg. air quality</div>
          <div className="kpi-value">{avgCo2}<small>ppm CO2</small></div>
          <div className="kpi-sub">{avgCo2 > 1000 ? "above" : "below"} the 1000 ppm limit</div>
        </div>
      </div>
    </div>
  );
}

function RoomTiles() {
  const { snapshot, highlight } = useDemoStore();
  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title"><Icon name="building" size={16} /> Rooms</h2>
      </div>
      <div className="panel-body">
        <div className="tiles">
          {snapshot.rooms.map((r) => (
            <Link key={r.id} to={`/rooms/${r.id}`} className={`tile ${highlight.includes(r.id) ? "hl" : ""}`}>
              <div className="tile-top">
                <span className="tile-name">{r.name}</span>
                <span className={`pill pill-${r.status}`}>{STATUS_LABEL[r.status]}</span>
              </div>
              <div className="bar"><span style={{ width: `${r.predictions.crowding_pct}%`, background: heat(r.predictions.crowding_pct / 100) }} /></div>
              <div className="tile-stats">
                <span><Icon name="users" size={12} /> {r.latest.occupancy}/{r.capacity}</span>
                <span><Icon name="wind" size={12} /> {r.latest.co2_ppm}</span>
                <span><Icon name="thermo" size={12} /> {r.latest.temperature_c}°</span>
                <span><Icon name="bolt" size={12} /> {r.latest.energy_kwh}</span>
              </div>
              <div className="muted" style={{ fontSize: "0.75rem" }}>
                {r.schedule.current_class
                  ? `Now: ${r.schedule.current_class.subject}`
                  : r.schedule.next_class
                    ? `Next: ${r.schedule.next_class.subject} · ${r.schedule.next_class.start}`
                    : "No more classes today"}
                {r.data_source.startsWith("UCI") && " · UCI-based"}
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function Overview() {
  const { snapshot } = useDemoStore();
  return (
    <div className="shell">
      <TopBar />
      <div className="page-head">
        <div>
          <div className="eyebrow">Building overview</div>
          <h1>Engineering Block</h1>
          <p>{snapshot.generated_at} · {snapshot.rooms.length} rooms · simulated live feed, modelled on real UCI sensor data</p>
        </div>
      </div>
      <Kpis />
      <div className="main-grid">
        <div className="col">
          <FloorPlan />
          <ActionsPanel />
          <RoomTiles />
          <EventFeed />
        </div>
        <div className="col sticky-col">
          <Copilot />
        </div>
      </div>
    </div>
  );
}
