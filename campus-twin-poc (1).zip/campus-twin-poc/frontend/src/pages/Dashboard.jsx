import { useMemo, useState } from "react";
import { useLatestReading, useReadingsHistory, useTimetable } from "../hooks/useFirestoreRoom";
import { ROOM_ID } from "../firebase";
import { useAuth } from "../context/AuthContext";
import LineChart from "../components/LineChart";
import AddReadingForm from "../components/AddReadingForm";
import StatTile from "../components/StatTile";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const { reading, loading } = useLatestReading(ROOM_ID);
  const { readings } = useReadingsHistory(ROOM_ID, 96);
  const timetable = useTimetable(ROOM_ID);
  const [showTable, setShowTable] = useState(false);

  const co2Points = useMemo(
    () =>
      readings
        .filter((r) => r.co2_ppm != null)
        .map((r) => ({ y: r.co2_ppm, label: new Date(r.timestamp).toLocaleString() })),
    [readings]
  );
  const energyPoints = useMemo(
    () =>
      readings
        .filter((r) => r.energy_kwh != null)
        .map((r) => ({ y: r.energy_kwh, label: new Date(r.timestamp).toLocaleString() })),
    [readings]
  );

  if (loading) return <div className="page-loading">Loading room-a…</div>;

  return (
    <div className="dashboard">
      <header className="dashboard-header">
        <div>
          <h1>Campus Digital Twin — room-a</h1>
          {reading && <p className="muted">Last updated {new Date(reading.timestamp).toLocaleString()}</p>}
        </div>
        <div className="header-right">
          <span className="muted">{user?.email}</span>
          <button className="link-button" onClick={logout}>Sign out</button>
        </div>
      </header>

      {reading?.overcrowded && (
        <div className="alert alert-critical">
          Overcrowding flagged — CO2 {reading.co2_ppm?.toFixed(0)} ppm while occupied.
        </div>
      )}
      {reading?.energy_anomaly && (
        <div className="alert alert-warning">
          Abnormal energy consumption flagged — {reading.energy_kwh?.toFixed(2)} kWh.
        </div>
      )}

      <section className="stat-row">
        <StatTile
          label="Occupied"
          value={reading?.occupied ? "Yes" : "No"}
          status={reading?.occupied ? "good" : undefined}
        />
        <StatTile
          label="CO2"
          value={reading?.co2_ppm?.toFixed(0) ?? "—"}
          unit="ppm"
          status={reading?.overcrowded ? "critical" : "good"}
        />
        <StatTile label="Temperature" value={reading?.temperature_c?.toFixed(1) ?? "—"} unit="°C" />
        <StatTile
          label="Energy"
          value={reading?.energy_kwh?.toFixed(2) ?? "—"}
          unit="kWh"
          status={reading?.energy_anomaly ? "warning" : undefined}
        />
      </section>

      <section className="charts-row">
        <div className="card">
          <LineChart title="CO2 (crowding proxy)" unit="ppm" points={co2Points} colorVar="--series-1" />
        </div>
        <div className="card">
          <LineChart title="Energy consumption" unit="kWh" points={energyPoints} colorVar="--series-2" />
        </div>
      </section>

      <section className="lower-row">
        <AddReadingForm />

        <div className="card">
          <h3>Timetable</h3>
          <button className="link-button" onClick={() => setShowTable((s) => !s)}>
            {showTable ? "Hide" : "Show"} schedule table
          </button>
          {showTable && (
            <table className="data-table">
              <thead>
                <tr>
                  <th>Day</th>
                  <th>Time</th>
                  <th>Subject</th>
                  <th>Capacity</th>
                  <th>Expected</th>
                </tr>
              </thead>
              <tbody>
                {timetable.map((t) => (
                  <tr key={`${t.day_of_week}-${t.start_time}`}>
                    <td>{t.day_of_week}</td>
                    <td>{t.start_time}–{t.end_time}</td>
                    <td>{t.subject}</td>
                    <td>{t.capacity}</td>
                    <td>{t.expected_headcount}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </section>
    </div>
  );
}
