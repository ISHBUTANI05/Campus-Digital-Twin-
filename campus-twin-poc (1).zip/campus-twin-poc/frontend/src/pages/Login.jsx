import { useState } from "react";
import { useAuth } from "../context/AuthContext";
import { DEMO_MODE } from "../config";
import { BrandMark } from "../components/TopBar";
import Icon from "../components/Icon";

// Decorative isometric-ish building for the hero side.
function HeroArt() {
  const rooms = [
    [60, 40, 150, 110, "#f87171"],
    [220, 40, 200, 110, "#22d3ee"],
    [430, 40, 130, 110, "#fbbf24"],
    [60, 190, 230, 110, "#34d399"],
    [300, 190, 150, 110, "#5b8cff"],
    [460, 190, 100, 110, "#a78bfa"],
  ];
  return (
    <svg className="auth-hero-art" viewBox="0 0 620 360" aria-hidden="true">
      <g transform="skewY(-8) skewX(18) translate(-40 60)">
        <rect x="40" y="20" width="540" height="300" rx="20" fill="rgba(91,140,255,0.05)" stroke="rgba(148,178,255,0.25)" strokeWidth="2" />
        <line x1="60" y1="170" x2="560" y2="170" className="fp-flow" />
        {rooms.map(([x, y, w, h, c], i) => (
          <g key={i}>
            <rect x={x} y={y} width={w} height={h} rx="12" fill={c} fillOpacity="0.14" stroke={c} strokeOpacity="0.6" />
            {Array.from({ length: 6 + i * 2 }).map((_, j) => (
              <circle key={j} className="fp-person" cx={x + 16 + ((j * 37) % (w - 30))} cy={y + 24 + ((j * 23) % (h - 40))} r="3.5" fill={c} style={{ animationDelay: `${(j % 5) * 0.4}s` }} />
            ))}
          </g>
        ))}
      </g>
    </svg>
  );
}

export default function Login() {
  const { login, signup, error } = useAuth();
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    setLocalError(null);
    try {
      if (mode === "login") await login(email, password);
      else await signup(email, password);
    } catch (err) {
      setLocalError(err.message);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="auth-screen">
      <div className="auth-hero">
        <div className="brand">
          <BrandMark />
          <div>
            <div className="brand-name">CampusTwin</div>
            <div className="brand-sub">Engineering Block · Digital Twin</div>
          </div>
        </div>
        <div style={{ position: "relative" }}>
          <div className="eyebrow">Live campus intelligence</div>
          <h1>Your building, <span>alive and thinking.</span></h1>
          <p>
            Occupancy, air quality and energy for every room, streamed into a digital twin, with an AI
            copilot that answers questions and decides what to do next.
          </p>
        </div>
        <div className="auth-features">
          <span><Icon name="users" size={16} /> Crowding prediction</span>
          <span><Icon name="bolt" size={16} /> Energy anomaly detection</span>
          <span><Icon name="sparkles" size={16} /> AI next-step planning</span>
        </div>
        <HeroArt />
      </div>

      <div className="auth-side">
        <form className="panel auth-card" onSubmit={submit}>
          <h2>{mode === "login" ? "Welcome back" : "Create an account"}</h2>
          <p className="muted" style={{ margin: 0 }}>Sign in to open the twin.</p>

          <label>
            Email
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@college.edu" required />
          </label>
          <label>
            Password
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} minLength={6} placeholder="••••••" required />
          </label>

          {(localError || error) && <div className="error">{localError || error}</div>}

          <button type="submit" className="btn btn-primary" disabled={busy}>
            {busy ? "Please wait…" : mode === "login" ? "Enter the twin" : "Sign up"} <Icon name="arrowRight" size={16} />
          </button>

          <button type="button" className="link-button" onClick={() => setMode(mode === "login" ? "signup" : "login")}>
            {mode === "login" ? "Need an account? Sign up" : "Have an account? Sign in"}
          </button>

          {DEMO_MODE && <div className="demo-hint">Demo mode: any email and a 6+ character password will work.</div>}
        </form>
      </div>
    </div>
  );
}
