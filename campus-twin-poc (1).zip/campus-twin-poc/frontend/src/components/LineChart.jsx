import { useId, useMemo, useRef, useState } from "react";

/**
 * Single-series area chart: gradient fill, 2px line, glowing end point,
 * optional dashed threshold line, hover crosshair + tooltip.
 */
export default function LineChart({ title, unit, points, colorVar = "--accent", height = 170, threshold, decimals = 1 }) {
  const svgRef = useRef(null);
  const gid = useId().replace(/:/g, "");
  const [hover, setHover] = useState(null);
  const width = 560;
  const padL = 44, padR = 14, padT = 12, padB = 26;
  const innerW = width - padL - padR;
  const innerH = height - padT - padB;

  const geo = useMemo(() => {
    if (!points.length) return null;
    const ys = points.map((p) => p.y);
    let yMin = Math.min(...ys, threshold ?? Infinity);
    let yMax = Math.max(...ys, threshold ?? -Infinity);
    const padY = (yMax - yMin) * 0.12 || 1;
    yMin -= padY;
    yMax += padY;
    const x = (i) => padL + (i / Math.max(1, points.length - 1)) * innerW;
    const y = (v) => padT + innerH - ((v - yMin) / (yMax - yMin)) * innerH;
    const line = points.map((p, i) => `${i ? "L" : "M"}${x(i).toFixed(1)},${y(p.y).toFixed(1)}`).join(" ");
    const area = `${line} L${x(points.length - 1).toFixed(1)},${padT + innerH} L${padL},${padT + innerH} Z`;
    const ticks = [0, 0.5, 1].map((f) => {
      const v = yMin + (yMax - yMin) * f;
      return { v, y: y(v) };
    });
    const xLabels = [0, Math.floor((points.length - 1) / 2), points.length - 1].map((i) => ({ i, x: x(i), label: points[i].label }));
    return { x, y, line, area, ticks, xLabels };
  }, [points, threshold, innerW, innerH]);

  const onMove = (e) => {
    if (!points.length) return;
    const rect = svgRef.current.getBoundingClientRect();
    const relX = ((e.clientX - rect.left) / rect.width) * width;
    const f = Math.min(1, Math.max(0, (relX - padL) / innerW));
    setHover(Math.round(f * (points.length - 1)));
  };

  const color = `var(${colorVar})`;
  const last = points[points.length - 1];
  const hp = hover != null ? points[hover] : null;

  return (
    <div className="chart">
      <div className="chart-head">
        <span className="chart-title">{title}</span>
        {last && (
          <span className="chart-now" style={{ color }}>
            {last.y.toFixed(decimals)} <small>{unit}</small>
          </span>
        )}
      </div>
      <svg ref={svgRef} viewBox={`0 0 ${width} ${height}`} onMouseMove={onMove} onMouseLeave={() => setHover(null)}>
        <defs>
          <linearGradient id={`area-${gid}`} x1="0" x2="0" y1="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.35" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {geo && (
          <>
            {geo.ticks.map((t, i) => (
              <g key={i}>
                <line x1={padL} x2={width - padR} y1={t.y} y2={t.y} className="gridline" />
                <text x={padL - 8} y={t.y + 4} textAnchor="end" className="axis-label">{t.v.toFixed(t.v > 100 ? 0 : 1)}</text>
              </g>
            ))}
            {geo.xLabels.map((l, i) => (
              <text key={i} x={l.x} y={height - 6} textAnchor={i === 0 ? "start" : i === 2 ? "end" : "middle"} className="axis-label">{l.label}</text>
            ))}
            {threshold != null && (
              <line x1={padL} x2={width - padR} y1={geo.y(threshold)} y2={geo.y(threshold)} className="threshold" />
            )}
            <path d={geo.area} fill={`url(#area-${gid})`} />
            <path d={geo.line} fill="none" stroke={color} strokeWidth="2" strokeLinejoin="round" />
            <circle cx={geo.x(points.length - 1)} cy={geo.y(last.y)} r="4.5" fill={color} style={{ filter: `drop-shadow(0 0 6px ${color})` }} />
            {hp && (
              <>
                <line x1={geo.x(hover)} x2={geo.x(hover)} y1={padT} y2={padT + innerH} className="crosshair" />
                <circle cx={geo.x(hover)} cy={geo.y(hp.y)} r="4" fill="var(--bg)" stroke={color} strokeWidth="2" />
              </>
            )}
          </>
        )}
      </svg>
      {hp && geo && (
        <div className="chart-tip" style={{ left: `${(geo.x(hover) / width) * 100}%` }}>
          {hp.label} · <strong>{hp.y.toFixed(decimals)}</strong> {unit}
        </div>
      )}
    </div>
  );
}
