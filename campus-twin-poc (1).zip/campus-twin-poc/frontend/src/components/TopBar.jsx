import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { useDemoStore } from "../store/DemoStore";
import Icon from "./Icon";

export function BrandMark({ size = 34 }) {
  return (
    <div className="brand-mark" style={{ width: size, height: size }}>
      <svg width={size * 0.55} height={size * 0.55} viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2" strokeLinejoin="round">
        <path d="M12 2 3 7v10l9 5 9-5V7l-9-5z" />
        <path d="M3 7l9 5 9-5M12 12v10" strokeOpacity="0.6" />
      </svg>
    </div>
  );
}

export function AiBadge() {
  const { ai } = useDemoStore();
  if (!ai.checked) return <span className="pill pill-muted">Connecting…</span>;
  return ai.enabled ? (
    <span className="pill pill-ai" title={`Answers and plans come from ${ai.model}`}>
      <span className="dot dot-live" /> Claude · {ai.model}
    </span>
  ) : (
    <span className="pill pill-muted" title="Set ANTHROPIC_API_KEY in frontend/.env to use Claude">
      <Icon name="cpu" size={12} /> Offline brain
    </span>
  );
}

export default function TopBar() {
  const { user, logout } = useAuth();
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  return (
    <header className="topbar">
      <Link to="/" className="brand">
        <BrandMark />
        <div>
          <div className="brand-name">CampusTwin</div>
          <div className="brand-sub">Engineering Block · Digital Twin</div>
        </div>
      </Link>
      <div className="topbar-spacer" />
      <div className="topbar-meta">
        <span className="pill pill-good"><span className="dot dot-live" /> LIVE</span>
        <AiBadge />
        <span className="clock">{now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" })}</span>
        <span className="user-chip">
          <span className="avatar">{(user?.email || "?")[0].toUpperCase()}</span>
          <button className="btn btn-ghost btn-sm" onClick={logout} title="Sign out">
            <Icon name="logout" size={15} />
          </button>
        </span>
      </div>
    </header>
  );
}
