import { useDemoStore } from "../store/DemoStore";
import Icon from "./Icon";

export default function EventFeed() {
  const { events, snapshot } = useDemoStore();
  const alerts = snapshot.rooms
    .filter((r) => r.status !== "good")
    .map((r) => ({
      kind: r.status,
      title: r.predictions.overcrowded ? `Overcrowding · ${r.name}` : r.predictions.energy_anomaly ? `Energy anomaly · ${r.name}` : `Air quality · ${r.name}`,
      detail: r.predictions.overcrowded
        ? `${r.latest.occupancy}/${r.capacity} people, CO2 ${r.latest.co2_ppm} ppm`
        : r.predictions.energy_anomaly
          ? `${r.latest.energy_kwh} kWh (z ${r.predictions.energy_z})`
          : `CO2 ${r.latest.co2_ppm} ppm`,
      at: null,
    }));
  const items = [...alerts, ...events];
  const tone = { critical: "var(--crit)", warning: "var(--warn)", action: "var(--good)", manual: "var(--accent-2)" };

  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title"><Icon name="activity" size={16} /> Twin activity</h2>
      </div>
      <div className="panel-body">
        {items.length === 0 ? (
          <div className="muted">No alerts or actions yet.</div>
        ) : (
          <div className="events">
            {items.map((e, i) => (
              <div className="event" key={i}>
                <time>{e.at ? e.at.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }) : "now"}</time>
                <div className="rail"><i style={{ "--tone": tone[e.kind] }} /></div>
                <div>
                  <b>{e.title}</b>
                  <span>{e.detail}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </section>
  );
}
