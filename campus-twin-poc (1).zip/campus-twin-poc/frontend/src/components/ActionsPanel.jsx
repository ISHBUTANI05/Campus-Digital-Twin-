import { useDemoStore } from "../store/DemoStore";
import Icon, { ACTION_ICONS } from "./Icon";

const TYPE_LABEL = {
  ventilation: "Ventilation",
  relocate: "Relocate",
  energy: "Energy",
  maintenance: "Maintenance",
  schedule: "Schedule",
  comfort: "Comfort",
};

export default function ActionsPanel({ roomId }) {
  const { advice, advising, refreshAdvice, applyAction, done, stale, roomsById, setHighlight } = useDemoStore();

  const actions = (advice?.actions || []).filter(
    (a) => !roomId || a.room_id === roomId || a.target_room_id === roomId
  );

  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title">
          <Icon name="sparkles" size={16} style={{ color: "var(--ai)" }} /> {roomId ? "Recommended for this room" : "Next best actions"}
        </h2>
        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          {advice && (
            <span className={`pill ${advice.source === "claude" ? "pill-ai" : "pill-muted"}`}>
              {advice.source === "claude" ? "Planned by Claude" : "Rule engine"}
            </span>
          )}
          <button className="btn btn-sm" onClick={refreshAdvice} disabled={advising} title="Re-plan from the current twin state">
            {stale && !advising && <span className="stale-dot" title="The twin changed since this plan" />}
            <Icon name="refresh" size={14} className={advising ? "spin" : ""} />
            {advising ? "Planning…" : "Re-plan"}
          </button>
        </div>
      </div>
      <div className="panel-body">
        {!roomId && advice?.summary && !advising && (
          <div className="plan-summary">
            <Icon name="sparkles" size={18} />
            <div>{advice.summary}</div>
          </div>
        )}

        {advising && (
          <div className="actions-list">
            {[0, 1, 2].map((i) => <div key={i} className="skeleton" />)}
          </div>
        )}

        {!advising && actions.length === 0 && (
          <div className="empty-note">
            <Icon name="check" size={20} style={{ color: "var(--good)" }} />
            <div>{roomId ? "Nothing to do here. This room is within normal limits." : "All clear. No actions needed right now."}</div>
          </div>
        )}

        {!advising && actions.length > 0 && (
          <div className="actions-list">
            {actions.map((a, i) => {
              const key = `${a.room_id}:${a.action_type}:${a.title}`;
              const isDone = done[key];
              const rooms = [a.room_id, a.target_room_id].filter(Boolean);
              return (
                <article
                  key={key}
                  className={`action p-${a.priority} ${isDone ? "is-done" : ""}`}
                  style={{ animationDelay: `${i * 60}ms` }}
                  onMouseEnter={() => setHighlight(rooms)}
                >
                  <div className="action-top">
                    <span className="action-type">
                      <Icon name={ACTION_ICONS[a.action_type] || "activity"} size={14} /> {TYPE_LABEL[a.action_type]}
                    </span>
                    <span className={`pill ${a.priority === "critical" ? "pill-critical" : a.priority === "low" ? "pill-muted" : "pill-warning"}`}>
                      {a.priority}
                    </span>
                  </div>
                  <h4>{a.title}</h4>
                  <p>{a.rationale}</p>
                  <div className="impact"><Icon name="arrowRight" size={14} /> {a.expected_impact}</div>
                  <div className="action-foot">
                    <span className="muted" style={{ fontSize: "0.75rem" }}>
                      {rooms.map((id) => roomsById[id]?.name).join(" → ")}
                    </span>
                    {isDone ? (
                      <span className="applied"><Icon name="check" size={15} /> Applied</span>
                    ) : (
                      <button className="btn btn-primary btn-sm" onClick={() => applyAction(a)}>
                        Apply to twin
                      </button>
                    )}
                  </div>
                </article>
              );
            })}
          </div>
        )}
      </div>
    </section>
  );
}
