import { useEffect, useRef, useState } from "react";
import { useDemoStore } from "../store/DemoStore";
import RichText from "./RichText";
import Icon from "./Icon";

const DEFAULT_SUGGESTIONS = [
  "What should we do next?",
  "Which rooms are overcrowded right now?",
  "Any abnormal energy consumption?",
  "Find a free room for 40 people",
  "Which rooms will peak soonest?",
];

export default function Copilot({ suggestions = DEFAULT_SUGGESTIONS }) {
  const { messages, asking, ask, ai, roomsById, setHighlight, clearChat } = useDemoStore();
  const [text, setText] = useState("");
  const scroller = useRef(null);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight });
  }, [messages, asking]);

  const send = (q) => {
    const question = (q ?? text).trim();
    if (!question) return;
    setText("");
    ask(question);
  };

  return (
    <section className="panel copilot">
      <div className="copilot-head">
        <div className={`orb ${asking ? "busy" : ""} ${ai.enabled ? "" : "off"}`} />
        <div style={{ flex: 1 }}>
          <div className="copilot-title">Twin Copilot</div>
          <div className="copilot-sub">
            {ai.enabled ? `Reasoning with ${ai.model} over live twin data` : "Offline brain · grounded in live twin data"}
          </div>
        </div>
        {messages.length > 0 && (
          <button className="btn btn-ghost btn-sm" onClick={clearChat} title="Clear conversation">
            <Icon name="trash" size={14} />
          </button>
        )}
      </div>

      <div className="copilot-msgs" ref={scroller} aria-live="polite">
        {messages.length === 0 && !asking && (
          <div className="copilot-empty">
            <Icon name="sparkles" size={28} style={{ color: "var(--ai)" }} />
            <h3>Ask the twin anything</h3>
            <div className="muted" style={{ fontSize: "0.85rem" }}>
              Crowding, air quality, energy, schedules, or what to do next.
            </div>
            <div className="chips">
              {suggestions.map((s) => (
                <button key={s} type="button" className="chip" onClick={() => send(s)}>{s}</button>
              ))}
            </div>
          </div>
        )}

        {messages.map((m, i) =>
          m.role === "user" ? (
            <div key={i} className="msg msg-user">{m.text}</div>
          ) : (
            <div key={i} className="msg msg-assistant">
              <RichText text={m.text} />
              <div className="msg-foot">
                {(m.rooms || []).map((id) => (
                  <button key={id} className="room-tag" onClick={() => setHighlight([id])}>
                    {roomsById[id]?.name}
                  </button>
                ))}
                <span className="source-tag">
                  <Icon name={m.source === "claude" ? "sparkles" : "cpu"} size={11} />
                  {m.source === "claude" ? "Claude" : "Offline brain"}
                </span>
              </div>
              {i === messages.length - 1 && m.followUps?.length > 0 && !asking && (
                <div className="followups" style={{ marginTop: 8 }}>
                  {m.followUps.map((f) => (
                    <button key={f} className="chip" onClick={() => send(f)}>{f}</button>
                  ))}
                </div>
              )}
            </div>
          )
        )}

        {asking && (
          <div className="msg msg-assistant">
            <span className="typing"><i /><i /><i /></span>
          </div>
        )}
      </div>

      <form
        className="copilot-form"
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
      >
        <input
          type="text"
          placeholder="Ask about crowding, energy, where to move a class…"
          value={text}
          onChange={(e) => setText(e.target.value)}
          aria-label="Ask the twin"
        />
        <button type="submit" className="btn btn-primary send-btn" disabled={asking || !text.trim()} aria-label="Send">
          <Icon name="send" size={16} />
        </button>
      </form>
    </section>
  );
}
