export default function StatTile({ label, value, unit, status }) {
  return (
    <div className={`stat-tile ${status ? `status-${status}` : ""}`}>
      <div className="stat-label">{label}</div>
      <div className="stat-value">
        {value}
        {unit && <span className="stat-unit"> {unit}</span>}
      </div>
    </div>
  );
}
