// Renders the copilot's plain-text answers: paragraphs, "- " bullets, **bold**.
function inline(text) {
  return text.split(/(\*\*[^*]+\*\*)/g).map((part, i) =>
    part.startsWith("**") && part.endsWith("**") ? <strong key={i}>{part.slice(2, -2)}</strong> : part
  );
}

export default function RichText({ text }) {
  const blocks = [];
  let list = null;
  for (const raw of text.split("\n")) {
    const line = raw.trim();
    if (/^[-•*]\s+/.test(line)) {
      if (!list) blocks.push((list = { type: "ul", items: [] }));
      list.items.push(line.replace(/^[-•*]\s+/, ""));
    } else {
      list = null;
      if (line) blocks.push({ type: "p", text: line });
    }
  }
  return blocks.map((b, i) =>
    b.type === "ul" ? (
      <ul key={i}>{b.items.map((it, j) => <li key={j}>{inline(it)}</li>)}</ul>
    ) : (
      <p key={i}>{inline(b.text)}</p>
    )
  );
}
