import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useDemoStore } from "../store/DemoStore";
import { heat, HEAT_GRADIENT, LAYERS, STATUS_COLOR, STATUS_LABEL } from "../lib/colors";
import Icon from "./Icon";

const W = 1000;
const H = 560;

// Hand-laid floor: top wing, corridor, bottom wing.
const LAYOUT = {
  "room-a": { x: 40, y: 40, w: 260, h: 210 },
  "room-b": { x: 312, y: 40, w: 380, h: 210 },
  "room-c": { x: 704, y: 40, w: 256, h: 210 },
  "room-d": { x: 40, y: 310, w: 400, h: 210 },
  "room-e": { x: 452, y: 310, w: 300, h: 210 },
  "room-f": { x: 764, y: 310, w: 196, h: 210 },
};

function rand(seed) {
  const x = Math.sin(seed * 9301 + 49297) * 233280;
  return x - Math.floor(x);
}

function People({ box, count, color, roomIdx }) {
  const n = Math.min(60, Math.ceil(count / 2));
  const pad = 18;
  const top = box.y + 50;
  const bottom = box.y + box.h - 62;
  const dots = [];
  for (let i = 0; i < n; i++) {
    const s = roomIdx * 1000 + i;
    dots.push(
      <circle
        key={i}
        className="fp-person"
        cx={box.x + pad + rand(s) * (box.w - pad * 2)}
        cy={top + rand(s + 0.5) * Math.max(10, bottom - top)}
        r={3.6}
        fill={color}
        style={{ animationDelay: `${(rand(s + 0.3) * 3).toFixed(2)}s` }}
      />
    );
  }
  return <g opacity="0.9">{dots}</g>;
}

export default function FloorPlan() {
  const { snapshot, highlight } = useDemoStore();
  const navigate = useNavigate();
  const [layer, setLayer] = useState("crowding");
  const [hover, setHover] = useState(null);
  const L = LAYERS[layer];
  const rooms = snapshot.rooms;
  const hovered = useMemo(() => rooms.find((r) => r.id === hover), [rooms, hover]);

  return (
    <section className="panel">
      <div className="panel-head">
        <h2 className="panel-title"><Icon name="layers" size={16} /> Live floor twin</h2>
        <div className="layer-toggle" role="tablist" aria-label="Heat map layer">
          {Object.entries(LAYERS).map(([k, v]) => (
            <button key={k} className={k === layer ? "on" : ""} onClick={() => setLayer(k)} role="tab" aria-selected={k === layer}>
              {v.label}
            </button>
          ))}
        </div>
      </div>
      <div className="panel-body">
        <div className="floorplan">
          <svg viewBox={`0 0 ${W} ${H}`} role="img" aria-label="Floor plan of the building with live room status">
            <defs>
              <pattern id="fp-hatch" width="8" height="8" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
                <line x1="0" y1="0" x2="0" y2="8" stroke="rgba(148,178,255,0.06)" strokeWidth="2" />
              </pattern>
              {rooms.map((r) => (
                <radialGradient key={r.id} id={`g-${r.id}`} cx="30%" cy="30%" r="90%">
                  <stop offset="0%" stopColor={heat(L.value(r))} stopOpacity="0.45" />
                  <stop offset="100%" stopColor={heat(L.value(r))} stopOpacity="0.08" />
                </radialGradient>
              ))}
            </defs>

            {/* shell of the building */}
            <rect x="20" y="20" width={W - 40} height={H - 40} rx="22" fill="url(#fp-hatch)" stroke="var(--line-strong)" strokeWidth="2" />
            <rect x="40" y="262" width={W - 80} height="36" rx="10" fill="rgba(34,211,238,0.04)" stroke="rgba(34,211,238,0.15)" />
            <line x1="60" y1="280" x2={W - 60} y2="280" className="fp-flow" />
            <text x={W / 2} y="284" textAnchor="middle" fill="var(--muted)" fontSize="10" letterSpacing="4">CORRIDOR · GROUND FLOOR</text>
            <rect x="8" y="262" width="16" height="36" rx="4" fill="var(--accent-2)" fillOpacity="0.4" />
            <rect x={W - 24} y="262" width="16" height="36" rx="4" fill="var(--accent-2)" fillOpacity="0.4" />

            {rooms.map((r, idx) => {
              const b = LAYOUT[r.id];
              const v = L.value(r);
              const c = heat(v);
              const isHl = highlight.includes(r.id);
              const doorY = b.y < 262 ? b.y + b.h : b.y;
              return (
                <g
                  key={r.id}
                  className="fp-room"
                  onMouseEnter={() => setHover(r.id)}
                  onMouseLeave={() => setHover(null)}
                  onClick={() => navigate(`/rooms/${r.id}`)}
                  tabIndex={0}
                  role="link"
                  aria-label={`${r.name}: ${STATUS_LABEL[r.status]}, ${L.label} ${L.text(r)}`}
                  onKeyDown={(e) => e.key === "Enter" && navigate(`/rooms/${r.id}`)}
                >
                  {isHl && <rect className="fp-glow" x={b.x - 5} y={b.y - 5} width={b.w + 10} height={b.h + 10} rx="18" />}
                  <rect className="fp-body" x={b.x} y={b.y} width={b.w} height={b.h} rx="14" fill={`url(#g-${r.id})`} />
                  <rect className="fp-outline" x={b.x} y={b.y} width={b.w} height={b.h} rx="14" />
                  {r.status === "critical" && (
                    <rect className="fp-pulse" x={b.x} y={b.y} width={b.w} height={b.h} rx="14" stroke="var(--crit)" />
                  )}
                  {/* door onto the corridor */}
                  <rect x={b.x + b.w / 2 - 22} y={doorY - 2} width="44" height="4" rx="2" fill="var(--bg)" />
                  <rect x={b.x + b.w / 2 - 22} y={doorY - 1} width="44" height="2" rx="1" fill={c} opacity="0.8" />

                  <People box={b} count={r.latest.occupancy} color={c} roomIdx={idx} />

                  <text className="fp-name" x={b.x + 16} y={b.y + 30}>{r.name}</text>
                  <circle cx={b.x + b.w - 20} cy={b.y + 25} r="6" fill={STATUS_COLOR[r.status]}>
                    {r.status !== "good" && <animate attributeName="opacity" values="1;0.3;1" dur="1.2s" repeatCount="indefinite" />}
                  </circle>
                  {r.predictions.energy_anomaly && (
                    <g className="fp-blink" transform={`translate(${b.x + b.w - 52}, ${b.y + 13})`} color="var(--warn)">
                      <Icon name="bolt" size={22} />
                    </g>
                  )}
                  {isHl && (
                    <g transform={`translate(${b.x + 16}, ${b.y + 40})`}>
                      <rect width="64" height="18" rx="9" fill="var(--ai)" fillOpacity="0.2" stroke="var(--ai)" />
                      <text x="32" y="13" textAnchor="middle" fill="var(--ai)" fontSize="10" fontWeight="700">✦ COPILOT</text>
                    </g>
                  )}
                  <text className="fp-big" x={b.x + 16} y={b.y + b.h - 22} style={{ fill: heat(Math.max(v, 0.3)) }}>{L.text(r)}</text>
                  <text className="fp-meta" x={b.x + b.w - 16} y={b.y + b.h - 24} textAnchor="end">
                    {r.latest.occupancy}/{r.capacity}
                  </text>
                </g>
              );
            })}
          </svg>

          {hovered && (
            <div
              className="fp-tooltip"
              style={{
                left: `${((LAYOUT[hovered.id].x + LAYOUT[hovered.id].w / 2) / W) * 100}%`,
                top: `${(LAYOUT[hovered.id].y / H) * 100}%`,
              }}
            >
              <h4>{hovered.name}</h4>
              <div className="kv">
                <span>Status</span><span style={{ color: STATUS_COLOR[hovered.status] }}>{STATUS_LABEL[hovered.status]}</span>
                <span>Occupancy</span><span>{hovered.latest.occupancy}/{hovered.capacity} ({hovered.predictions.crowding_pct}%)</span>
                <span>CO2</span><span>{hovered.latest.co2_ppm} ppm</span>
                <span>Temperature</span><span>{hovered.latest.temperature_c} °C</span>
                <span>Energy</span><span>{hovered.latest.energy_kwh} kWh</span>
                <span>Now</span><span>{hovered.schedule.current_class?.subject ?? "No class"}</span>
              </div>
            </div>
          )}
        </div>
        <div className="fp-legend" style={{ marginTop: 10, justifyContent: "space-between", flexWrap: "wrap" }}>
          <span style={{ display: "inline-flex", alignItems: "center", gap: 10 }}>
            {L.low} <span className="fp-legend-bar" style={{ background: HEAT_GRADIENT }} /> {L.high}
          </span>
          <span>Each dot ≈ 2 people · click a room to open it</span>
        </div>
      </div>
    </section>
  );
}
