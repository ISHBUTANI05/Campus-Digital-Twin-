import { useState } from "react";
import { addManualReading } from "../hooks/useFirestoreRoom";
import { ROOM_ID } from "../firebase";

/**
 * The demo "proof lever": type in a reading and watch the live state,
 * chart, and overcrowding/anomaly indicators update immediately — no
 * hardware required for the POC.
 */
export default function AddReadingForm() {
  const [occupied, setOccupied] = useState(true);
  const [co2, setCo2] = useState(1200);
  const [temp, setTemp] = useState(24);
  const [energy, setEnergy] = useState(2.5);
  const [busy, setBusy] = useState(false);
  const [savedAt, setSavedAt] = useState(null);

  const submit = async (e) => {
    e.preventDefault();
    setBusy(true);
    try {
      await addManualReading(ROOM_ID, {
        occupied,
        co2_ppm: Number(co2),
        temperature_c: Number(temp),
        energy_kwh: Number(energy),
      });
      setSavedAt(new Date().toLocaleTimeString());
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="card add-reading-form" onSubmit={submit}>
      <h3>Add a reading</h3>
      <p className="muted">
        Simulate a sensor update — try CO2 above 1000 ppm with the room occupied to trigger
        overcrowding, or a high energy value to test the anomaly flag.
      </p>

      <label className="checkbox-row">
        <input type="checkbox" checked={occupied} onChange={(e) => setOccupied(e.target.checked)} />
        Room occupied
      </label>

      <div className="field-grid">
        <label>
          CO2 (ppm)
          <input type="number" value={co2} onChange={(e) => setCo2(e.target.value)} step="10" />
        </label>
        <label>
          Temperature (°C)
          <input type="number" value={temp} onChange={(e) => setTemp(e.target.value)} step="0.1" />
        </label>
        <label>
          Energy (kWh)
          <input type="number" value={energy} onChange={(e) => setEnergy(e.target.value)} step="0.1" />
        </label>
      </div>

      <button type="submit" disabled={busy}>
        {busy ? "Saving…" : "Add reading"}
      </button>
      {savedAt && <span className="muted saved-note">Saved at {savedAt}</span>}
    </form>
  );
}
