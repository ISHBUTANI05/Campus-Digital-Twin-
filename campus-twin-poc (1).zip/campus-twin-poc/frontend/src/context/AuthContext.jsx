import { createContext, useContext, useEffect, useState } from "react";
import {
  onAuthStateChanged,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
} from "firebase/auth";
import { auth } from "../firebase";
import { DEMO_MODE } from "../config";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(DEMO_MODE ? null : undefined);
  const [error, setError] = useState(null);

  useEffect(() => {
    if (DEMO_MODE) return; // no network call in demo mode
    return onAuthStateChanged(auth, (u) => setUser(u));
  }, []);

  const login = async (email, password) => {
    setError(null);
    if (DEMO_MODE) {
      // No network dependency for the live demo — any credentials "work".
      setUser({ email });
      return;
    }
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      setError(e.message);
      throw e;
    }
  };

  const signup = async (email, password) => {
    setError(null);
    if (DEMO_MODE) {
      setUser({ email });
      return;
    }
    try {
      await createUserWithEmailAndPassword(auth, email, password);
    } catch (e) {
      setError(e.message);
      throw e;
    }
  };

  const logout = async () => {
    if (DEMO_MODE) {
      setUser(null);
      return;
    }
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, error, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  return useContext(AuthContext);
}
