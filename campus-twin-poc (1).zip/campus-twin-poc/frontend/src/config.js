// DEMO_MODE=true (default): everything runs self-contained with generated
// data and a local mock login — no Firebase network call required, so it's
// safe to present anywhere regardless of venue wifi or Firebase console setup.
// Set VITE_DEMO_MODE=false once the real Firestore/Auth path has been
// verified on a machine with normal internet.
export const DEMO_MODE = import.meta.env.VITE_DEMO_MODE !== "false";

// The AI copilot is configured server-side (ANTHROPIC_API_KEY in .env, read
// by vite.config.js), never in the browser. See server/twinAi.js.
