// Vercel serverless function for /api/twin/status, /api/twin/ask, /api/twin/advise.
// Same handler as the Vite dev server; set ANTHROPIC_API_KEY (and optionally
// TWIN_AI_MODEL) in the Vercel project's Environment Variables.
import { createTwinAi, handleTwinRequest } from "../../server/twinAi.js";

const twinAi = createTwinAi({
  apiKey: process.env.ANTHROPIC_API_KEY,
  model: process.env.TWIN_AI_MODEL || "claude-opus-5",
});

export default async function handler(req, res) {
  const [status, payload] = await handleTwinRequest(twinAi, {
    method: req.method,
    path: `/api/twin/${req.query.action}`,
    getBody: async () => (typeof req.body === "string" ? JSON.parse(req.body) : req.body),
  });
  res.status(status).json(payload);
}
