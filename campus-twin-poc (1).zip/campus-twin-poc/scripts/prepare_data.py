"""
Builds the seed dataset for the Campus Digital Twin POC (room-a).

Real data: UCI Occupancy Detection dataset (temperature, humidity, CO2, occupancy).
Synthetic data: energy consumption (calibrated, with injected anomalies) and a
weekly timetable. See ../data/README.md for the full schema and provenance.

Outputs:
  data/processed/seed_readings.csv
  data/processed/seed_readings.json   (list of dicts, ready for Firestore import)
  data/processed/timetable.csv
  data/processed/timetable.json
"""
import json
import numpy as np
import pandas as pd

RAW = "data/raw"
OUT = "data/processed"
ROOM_ID = "room-a"
RNG = np.random.default_rng(42)


def load_occupancy():
    frames = []
    for f in ["datatraining.txt", "datatest.txt", "datatest2.txt"]:
        frames.append(pd.read_csv(f"{RAW}/{f}", index_col=0))
    df = pd.concat(frames).drop_duplicates(subset="date").sort_values("date")
    df["date"] = pd.to_datetime(df["date"])
    df = df.set_index("date")

    resampled = pd.DataFrame({
        "temperature_c": df["Temperature"].resample("15min").mean(),
        "humidity_pct": df["Humidity"].resample("15min").mean(),
        "co2_ppm": df["CO2"].resample("15min").mean(),
        "occupied": df["Occupancy"].resample("15min").max(),
    }).dropna()
    resampled["occupied"] = resampled["occupied"].astype(bool)
    return resampled


def add_crowding_proxy(df):
    co2_min, co2_max = df["co2_ppm"].min(), df["co2_ppm"].max()
    df["crowding_index"] = ((df["co2_ppm"] - co2_min) / (co2_max - co2_min)).clip(0, 1).round(3)
    df["overcrowded"] = df["occupied"] & (df["co2_ppm"] > 1000)
    return df


def synth_energy(df):
    n = len(df)
    baseline = 0.4
    occ_load = df["occupied"].astype(float).values * RNG.uniform(1.2, 2.0, n)
    hvac_load = (df["temperature_c"] - 22).abs().values * 0.05
    noise = RNG.normal(0, 0.08, n)
    energy = baseline + occ_load + hvac_load + noise
    energy = np.clip(energy, 0.1, None)

    anomaly_mask = RNG.random(n) < 0.015
    energy[anomaly_mask] *= RNG.uniform(2.5, 4.0, anomaly_mask.sum())

    df["energy_kwh"] = energy.round(3)
    df["energy_anomaly"] = anomaly_mask
    return df


def build_timetable():
    subjects = [
        ("Data Structures Lab", 40, 38),
        ("Digital Electronics", 60, 45),
        ("Mini Project Review", 40, 20),
        ("Operating Systems", 60, 55),
        ("Elective: ML", 50, 48),
    ]
    slots = [("09:00", "10:30"), ("10:45", "12:15"), ("13:15", "14:45"), ("15:00", "16:30")]
    rows = []
    for day in ["Mon", "Tue", "Wed", "Thu", "Fri"]:
        for i, (start, end) in enumerate(slots):
            subject, capacity, expected = subjects[(hash(day) + i) % len(subjects)]
            rows.append({
                "room_id": ROOM_ID,
                "day_of_week": day,
                "start_time": start,
                "end_time": end,
                "subject": subject,
                "capacity": capacity,
                "expected_headcount": expected,
            })
    return pd.DataFrame(rows)


def main():
    df = load_occupancy()
    df = add_crowding_proxy(df)
    df = synth_energy(df)
    df["room_id"] = ROOM_ID
    df["source"] = "seed"

    df = df.reset_index().rename(columns={"date": "timestamp"})
    df["timestamp"] = df["timestamp"].dt.strftime("%Y-%m-%dT%H:%M:%S")

    cols = ["timestamp", "room_id", "temperature_c", "humidity_pct", "co2_ppm",
            "occupied", "crowding_index", "overcrowded", "energy_kwh",
            "energy_anomaly", "source"]
    df = df[cols]

    df.to_csv(f"{OUT}/seed_readings.csv", index=False)
    df.to_json(f"{OUT}/seed_readings.json", orient="records", indent=2)

    tt = build_timetable()
    tt.to_csv(f"{OUT}/timetable.csv", index=False)
    tt.to_json(f"{OUT}/timetable.json", orient="records", indent=2)

    print(f"readings: {len(df)} rows, {df['timestamp'].min()} -> {df['timestamp'].max()}")
    print(f"  occupied: {df['occupied'].sum()} / overcrowded: {df['overcrowded'].sum()} / "
          f"energy anomalies: {df['energy_anomaly'].sum()}")
    print(f"timetable: {len(tt)} rows")


if __name__ == "__main__":
    main()
